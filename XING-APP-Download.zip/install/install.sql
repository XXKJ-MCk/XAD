SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- 创建管理员用户表
CREATE TABLE IF NOT EXISTS `admin_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL COMMENT '用户名',
  `password` varchar(255) NOT NULL COMMENT '密码',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态：0禁用，1启用',
  `last_login` datetime DEFAULT NULL COMMENT '最后登录时间',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '更新时间',
  `remember_token` VARCHAR(64) DEFAULT NULL COMMENT '记住登录token',
  `token_expires` DATETIME DEFAULT NULL COMMENT 'token过期时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='管理员用户表';

-- 创建管理员登录日志表
CREATE TABLE IF NOT EXISTS `admin_login_logs` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `admin_id` int(11) DEFAULT 0 COMMENT '管理员ID，登录失败时为0',
    `username` varchar(50) NOT NULL COMMENT '登录用户名',
    `ip` varchar(45) NOT NULL COMMENT 'IP地址',
    `user_agent` varchar(255) DEFAULT NULL COMMENT '浏览器信息',
    `login_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '登录时间',
    `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态：1-成功，0-失败',
    `remark` varchar(255) DEFAULT NULL COMMENT '备注信息',
    PRIMARY KEY (`id`),
    KEY `idx_admin_id` (`admin_id`),
    KEY `idx_username` (`username`),
    KEY `idx_login_time` (`login_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='管理员登录日志表';

-- 创建系统配置表
CREATE TABLE IF NOT EXISTS `system_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(50) NOT NULL COMMENT '配置键名',
  `value` text COMMENT '配置值',
  `description` varchar(255) DEFAULT NULL COMMENT '配置描述',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统配置表';

-- 插入一些基础系统配置
INSERT INTO `system_config` (`key`, `value`, `description`, `created_at`) 
SELECT 'site_name', '后台管理系统', '站点名称', NOW()
WHERE NOT EXISTS (SELECT 1 FROM `system_config` WHERE `key` = 'site_name');

INSERT INTO `system_config` (`key`, `value`, `description`, `created_at`) 
SELECT 'site_description', '一个简单的后台管理系统', '站点描述', NOW()
WHERE NOT EXISTS (SELECT 1 FROM `system_config` WHERE `key` = 'site_description');

INSERT INTO `system_config` (`key`, `value`, `description`, `created_at`) 
SELECT 'upload_max_size', '2048', '最大上传大小(KB)', NOW()
WHERE NOT EXISTS (SELECT 1 FROM `system_config` WHERE `key` = 'upload_max_size');

INSERT INTO `system_config` (`key`, `value`, `description`, `created_at`) 
SELECT 'allowed_file_types', 'jpg,jpeg,png,gif,doc,docx,pdf', '允许上传的文件类型', NOW()
WHERE NOT EXISTS (SELECT 1 FROM `system_config` WHERE `key` = 'allowed_file_types');

-- 软件表
CREATE TABLE IF NOT EXISTS `software` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL COMMENT '软件名称',
  `version` varchar(50) NOT NULL COMMENT '版本号',
  `description` text COMMENT '软件描述',
  `file_path` varchar(255) DEFAULT NULL COMMENT '文件路径',
  `download_count` int(11) NOT NULL DEFAULT '0' COMMENT '下载次数',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态：1-启用，0-禁用',
  `size` varchar(20) DEFAULT NULL COMMENT '文件大小',
  `platform` varchar(50) DEFAULT NULL COMMENT '支持平台',
  `update_log` text COMMENT '更新日志',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `min_os_version` varchar(50) DEFAULT NULL COMMENT '最低系统版本',
  `recommended_os_version` varchar(50) DEFAULT NULL COMMENT '推荐操作系统版本',
  `release_date` DATE NULL COMMENT '发布日期',
  `icon_path` varchar(255) DEFAULT NULL COMMENT '图标路径',
  `screenshots` text DEFAULT NULL COMMENT '截图路径JSON数组',
  `code` varchar(32) NOT NULL DEFAULT '' COMMENT '软件编码',
  PRIMARY KEY (`id`),
  KEY `idx_download_count` (`download_count`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='软件表';

-- 登录尝试表
CREATE TABLE IF NOT EXISTS `login_attempts` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `ip` varchar(45) NOT NULL COMMENT 'IP地址',
    `attempt_time` datetime NOT NULL COMMENT '尝试时间',
    PRIMARY KEY (`id`),
    KEY `idx_ip_time` (`ip`, `attempt_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='登录尝试记录表';

-- 软件参数表
CREATE TABLE IF NOT EXISTS `software_params` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL COMMENT '参数名称',
  `description` varchar(255) DEFAULT NULL COMMENT '参数描述',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='软件参数表';

-- 软件参数值表
CREATE TABLE IF NOT EXISTS `software_param_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `software_id` int(11) NOT NULL COMMENT '软件ID',
  `param_id` int(11) NOT NULL COMMENT '参数ID',
  `value` varchar(255) NOT NULL COMMENT '参数值',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_software_param` (`software_id`,`param_id`),
  CONSTRAINT `fk_param_values_software` FOREIGN KEY (`software_id`) 
    REFERENCES `software` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_param_values_param` FOREIGN KEY (`param_id`) 
    REFERENCES `software_params` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='软件参数值表';

-- 创建操作日志表
CREATE TABLE IF NOT EXISTS `operation_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL COMMENT '用户ID',
  `action` varchar(50) NOT NULL COMMENT '操作行为',
  `ip` varchar(50) NOT NULL COMMENT 'IP地址',
  `user_agent` varchar(255) DEFAULT NULL COMMENT '用户代理',
  `description` text COMMENT '操作描述',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  CONSTRAINT `fk_operation_logs_user` FOREIGN KEY (`user_id`) 
    REFERENCES `admin_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='操作日志表';

-- 添加一些示例参数数据
INSERT INTO `software_params` (`name`, `description`) 
SELECT '语言', '软件支持的语言' WHERE NOT EXISTS (SELECT 1 FROM `software_params` WHERE `name` = '语言');

INSERT INTO `software_params` (`name`, `description`) 
SELECT '类型', '软件类型' WHERE NOT EXISTS (SELECT 1 FROM `software_params` WHERE `name` = '类型');

INSERT INTO `software_params` (`name`, `description`) 
SELECT '授权', '软件授权方式' WHERE NOT EXISTS (SELECT 1 FROM `software_params` WHERE `name` = '授权');

INSERT INTO `software_params` (`name`, `description`) 
SELECT '兼容性', '系统兼容性' WHERE NOT EXISTS (SELECT 1 FROM `software_params` WHERE `name` = '兼容性');

-- 创建线路表
CREATE TABLE IF NOT EXISTS `routes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `software_id` int(11) NOT NULL COMMENT '所属软件ID',
  `name` varchar(255) NOT NULL COMMENT '线路名称',
  `url` varchar(255) NOT NULL COMMENT '线路地址',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态：1-启用，0-禁用',
  `sort_order` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_sort_order` (`sort_order`),
  KEY `idx_software_id` (`software_id`),
  CONSTRAINT `fk_routes_software` FOREIGN KEY (`software_id`) 
    REFERENCES `software` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='线路表';

-- 添加下载日志表
CREATE TABLE IF NOT EXISTS `download_logs` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `software_id` int(11) NOT NULL COMMENT '软件ID',
    `route_id` int(11) DEFAULT NULL COMMENT '线路ID',
    `ip` varchar(45) NOT NULL COMMENT '下载者IP',
    `user_agent` varchar(255) DEFAULT NULL COMMENT '浏览器信息',
    `platform` varchar(20) DEFAULT NULL COMMENT '下载平台',
    `download_time` datetime NOT NULL COMMENT '下载时间',
    PRIMARY KEY (`id`),
    KEY `idx_software_id` (`software_id`),
    KEY `idx_route_id` (`route_id`),
    KEY `idx_download_time` (`download_time`),
    CONSTRAINT `fk_download_logs_software` FOREIGN KEY (`software_id`) 
        REFERENCES `software` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_download_logs_route` FOREIGN KEY (`route_id`) 
        REFERENCES `routes` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='下载日志表';

-- 在 software 表中添加 screenshots 字段
ALTER TABLE software ADD COLUMN screenshots TEXT AFTER description;

SET FOREIGN_KEY_CHECKS = 1;
<?php
// 在文件开头添加
define('IN_INSTALL', true);

error_reporting(E_ALL);
ini_set('display_errors', 1);

// 检查是否已安装
if (file_exists('../config/install.lock') && !isset($_GET['step'])) {
    die('程序已安装，如需重新安装请删除 config/install.lock 文件');
}

$step = isset($_GET['step']) ? intval($_GET['step']) : 0;
$action = isset($_POST['action']) ? $_POST['action'] : '';

// 添加检查安装状态的函数
function checkInstallation() {
    if (file_exists('../config/install.lock')) {
        $lockContent = file_get_contents('../config/install.lock');
        return [
            'installed' => true,
            'install_time' => $lockContent
        ];
    }
    return ['installed' => false];
}

// 检查安装状态
$installStatus = checkInstallation();

// 如果已安装且不是查看最后完成页面，则阻止访问
if ($installStatus['installed'] && $step != 5 && !isset($_POST['action'])) {
    die('
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>系统已安装</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    </head>
    <body>
        <div class="container mt-5">
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body text-center">
                            <h3 class="text-danger mb-3">系统已安装</h3>
                            <p>安装时间：' . $installStatus['install_time'] . '</p>
                            <p>如需重新安装，请删除 config/install.lock 文件</p>
                            <div class="mt-3">
                                <a href="../admin/login.php" class="btn btn-primary">进入后台</a>
                                <a href="../" class="btn btn-secondary">返回首页</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
    </html>
    ');
}

// 环境检查
function checkEnvironment() {
    $requirements = array(
        'php_version' => array(
            'name' => 'PHP版本 >= 7.0',
            'status' => version_compare(PHP_VERSION, '7.0.0', '>='),
            'current' => PHP_VERSION
        ),
        'pdo_mysql' => array(
            'name' => 'PDO MySQL扩展',
            'status' => extension_loaded('pdo_mysql'),
            'current' => extension_loaded('pdo_mysql') ? '已安装' : '未安装'
        ),
        'gd' => array(
            'name' => 'GD扩展',
            'status' => extension_loaded('gd'),
            'current' => extension_loaded('gd') ? '已安装' : '未安装'
        ),
        'curl' => array(
            'name' => 'CURL扩展',
            'status' => extension_loaded('curl'),
            'current' => extension_loaded('curl') ? '已安装' : '未安装'
        ),
        'config_writable' => array(
            'name' => 'config目录可写',
            'status' => is_writable('../config'),
            'current' => is_writable('../config') ? '可写' : '不可写'
        ),
        'upload_writable' => array(
            'name' => 'uploads目录可写',
            'status' => is_writable('../uploads'),
            'current' => is_writable('../uploads') ? '可写' : '不可写'
        ),
        'allow_url_fopen' => array(
            'name' => 'allow_url_fopen',
            'status' => ini_get('allow_url_fopen'),
            'current' => ini_get('allow_url_fopen') ? '开启' : '关闭'
        ),
        'max_execution_time' => array(
            'name' => '最大执行时间',
            'status' => true,
            'current' => ini_get('max_execution_time').'秒'
        ),
        'upload_max_filesize' => array(
            'name' => '最大上传限制',
            'status' => true,
            'current' => ini_get('upload_max_filesize')
        ),
        'post_max_size' => array(
            'name' => 'POST数据最大限制',
            'status' => true,
            'current' => ini_get('post_max_size')
        )
    );
    
    return $requirements;
}

// 数据库连接测试
function testDatabase($host, $port, $username, $password, $database) {
    try {
        $dsn = "mysql:host={$host};port={$port};charset=utf8mb4";
        $pdo = new PDO($dsn, $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // 尝试创建数据库
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$database}` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        return true;
    } catch (PDOException $e) {
        return $e->getMessage();
    }
}

// 处理表单提交
if ($action == 'test_db') {
    $result = testDatabase(
        $_POST['db_host'],
        $_POST['db_port'],
        $_POST['db_user'],
        $_POST['db_pass'],
        $_POST['db_name']
    );
    
    header('Content-Type: application/json');
    echo json_encode(['success' => $result === true, 'message' => $result !== true ? $result : '连接成功']);
    exit;
}

if ($action == 'install') {
    try {
        // 获取数据库配置
        $db_config = [
            'host' => $_POST['db_host'],
            'port' => $_POST['db_port'],
            'database' => $_POST['db_name'],
            'username' => $_POST['db_user'],
            'password' => $_POST['db_pass']
        ];

        // 创建配置文件
        $config = [
            'database' => $db_config,
            'system' => [
                'version' => '1.0.0',
                'build' => date('Ymd'),
                'release_date' => date('Y-m-d'),
                'name' => 'Admin System',
                'short_name' => 'Admin'
            ]
        ];
        
        // 保存配置文件
        if (!is_dir('../config')) {
            mkdir('../config', 0755, true);
        }
        
        $config_content = "<?php\nreturn " . var_export($config, true) . ";\n";
        if (!file_put_contents('../config/config.php', $config_content)) {
            throw new Exception('无法写入配置文件');
        }
        
        // 连接数据库
        $dsn = "mysql:host={$db_config['host']};port={$db_config['port']};dbname={$db_config['database']};charset=utf8mb4";
        $pdo = new PDO($dsn, $db_config['username'], $db_config['password']);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // 开始事务
        $pdo->beginTransaction();
        
        try {
            // 检查 install.sql 文件是否存在
            if (!file_exists('install.sql')) {
                throw new Exception('安装SQL文件不存在');
            }
            
            // 读取并执行SQL文件
            $sql = file_get_contents('install.sql');
            if (!$sql) {
                throw new Exception('无法读取SQL文件');
            }
            
            // 分割SQL语句
            $queries = array_filter(array_map('trim', explode(';', $sql)));
            
            foreach ($queries as $query) {
                if (!empty($query)) {
                    $pdo->exec($query);
                }
            }
            
            // 修改创建管理员账号的部分
            try {
                // 先获取和定义管理员信息
                $admin_username = $_POST['admin_username'];
                $admin_password = password_hash($_POST['admin_password'], PASSWORD_DEFAULT);

                // 检查用户名是否已存在
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM admin_users WHERE username = ?");
                $stmt->execute([$admin_username]);
                if ($stmt->fetchColumn() > 0) {
                    throw new Exception('管理员用户名已存在，请使用其他用户名');
                }
                
                // 创建管理员账号
                $stmt = $pdo->prepare("INSERT INTO admin_users (username, password, status, created_at) VALUES (?, ?, 1, NOW())");
                $stmt->execute([$admin_username, $admin_password]);
                
                // 提交事务
                $pdo->commit();
                
                // 创建必要的目录
                $dirs = ['../uploads', '../cache', '../logs', '../admin/pages'];
                foreach ($dirs as $dir) {
                    if (!file_exists($dir)) {
                        if (!mkdir($dir, 0755, true)) {
                            throw new Exception("无法创建目录: $dir");
                        }
                    }
                }
                
                // 创建安装锁定文件
                if (!file_put_contents('../config/install.lock', date('Y-m-d H:i:s'))) {
                    throw new Exception('无法创建安装锁定文件');
                }
                
                echo json_encode([
                    'success' => true,
                    'redirect' => 'index.php?step=5'
                ]);
                exit;
                
            } catch (Exception $e) {
                // 回滚事务
                $pdo->rollBack();
                echo json_encode([
                    'success' => false,
                    'message' => '安装失败：' . $e->getMessage()
                ]);
                exit;
            }
            
        } catch (Exception $e) {
            // 回滚事务
            $pdo->rollBack();
            throw $e;
        }
        
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => '安装失败：' . $e->getMessage()
        ]);
        exit;
    }
}

// 在 PHP 部分添加一个新的 action 处理进度查询
if ($action == 'import_progress') {
    // 这里可以实现实际的进度检查逻辑
    $progress = rand(0, 100); // 示例：随机进度
    echo json_encode(['progress' => $progress]);
    exit;
}

// 添加目录权限检查
function check_directory_permissions() {
    $directories = [
        '../config' => '0755',
        '../uploads' => '0755',
        '../cache' => '0755',
        '../logs' => '0755'
    ];
    
    $results = [];
    foreach ($directories as $dir => $required_permission) {
        if (!file_exists($dir)) {
            @mkdir($dir, octdec($required_permission), true);
        }
        
        $results[$dir] = [
            'exists' => file_exists($dir),
            'writable' => is_writable($dir),
            'permission' => substr(sprintf('%o', fileperms($dir)), -4)
        ];
    }
    
    return $results;
}

// 在安装过程中创建必要的目录
function create_required_directories() {
    $directories = [
        '../uploads',
        '../cache',
        '../logs',
        '../admin/pages'
    ];
    
    foreach ($directories as $dir) {
        if (!file_exists($dir)) {
            mkdir($dir, 0755, true);
        }
    }
}

// 检查目录是否可写
function checkDirectoryWritable($dir) {
    if (!file_exists($dir)) {
        if (!@mkdir($dir, 0755, true)) {
            return false;
        }
    }
    return is_writable($dir);
}

// 检查文件是否可写
function checkFileWritable($file) {
    if (file_exists($file)) {
        return is_writable($file);
    }
    $dir = dirname($file);
    return is_writable($dir);
}

// 清理安装临时文件
function cleanInstallFiles() {
    // 可以添加需要清理的临时文件
    $files = [
        '../install/install.sql',
        '../install/temp'
    ];
    
    foreach ($files as $file) {
        if (file_exists($file)) {
            if (is_dir($file)) {
                rmdir($file);
            } else {
                unlink($file);
            }
        }
    }
}

// 修改用户名检查的处理部分
if ($action == 'check_username') {
    try {
        // 从POST数据获取数据库配置
        $db_host = $_POST['db_host'] ?? 'localhost';
        $db_port = $_POST['db_port'] ?? '3306';
        $db_name = $_POST['db_name'] ?? '';
        $db_user = $_POST['db_user'] ?? '';
        $db_pass = $_POST['db_pass'] ?? '';

        $dsn = "mysql:host={$db_host};port={$db_port};dbname={$db_name};charset=utf8mb4";
        $pdo = new PDO($dsn, $db_user, $db_pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
        ]);

        $stmt = $pdo->prepare("SELECT COUNT(*) FROM admin_users WHERE username = ?");
        $stmt->execute([$_POST['username']]);
        $exists = $stmt->fetchColumn() > 0;
        
        echo json_encode(['available' => !$exists]);
    } catch (Exception $e) {
        echo json_encode(['error' => $e->getMessage()]);
    }
    exit;
}

// 添加目录权限验证
function validateDirectories() {
    $directories = [
        '../config' => 0755,
        '../uploads' => 0755,
        '../cache' => 0755,
        '../logs' => 0755
    ];
    
    $errors = [];
    foreach ($directories as $dir => $perm) {
        if (!file_exists($dir)) {
            if (!@mkdir($dir, $perm, true)) {
                $errors[] = "无法创建目录: $dir";
            }
        } elseif (!is_writable($dir)) {
            $errors[] = "目录不可写: $dir";
        }
    }
    return $errors;
}

// 防止目录遍历
$requested_path = realpath($path);
$base_path = realpath(__DIR__ . '/..');
if (strpos($requested_path, $base_path) !== 0) {
    die('非法访问');
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>系统安装</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
    <style>
    .install-steps {
        display: flex;
        justify-content: space-between;
        margin-bottom: 30px;
        position: relative;
    }
    
    .install-steps::before {
        content: '';
        position: absolute;
        top: 25px;
        left: 0;
        right: 0;
        height: 2px;
        background: #e9ecef;
        z-index: 1;
    }
    
    .step-item {
        text-align: center;
        position: relative;
        z-index: 2;
        background: #fff;
        padding: 0 10px;
    }
    
    .step-circle {
        width: 50px;
        height: 50px;
        border-radius: 50%;
        background: #e9ecef;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 10px;
        color: #6c757d;
        font-weight: bold;
        border: 2px solid #dee2e6;
    }
    
    .step-title {
        font-size: 14px;
        color: #6c757d;
    }
    
    .step-active .step-circle {
        background: #0d6efd;
        color: #fff;
        border-color: #0d6efd;
    }
    
    .step-active .step-title {
        color: #0d6efd;
        font-weight: bold;
    }
    
    .step-done .step-circle {
        background: #198754;
        color: #fff;
        border-color: #198754;
    }
    
    footer {
        margin-top: 2rem;
        border-top: 1px solid #eee;
        background-color: #f8f9fa;
    }
    
    footer p {
        margin-bottom: 0.3rem !important;
    }
    
    .container {
        min-height: calc(100vh - 200px);
        padding-bottom: 2rem;
    }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h3 class="text-center">系统安装向导</h3>
                    </div>
                    <div class="card-body">
                        <!-- 添加进度指示器 -->
                        <div class="install-steps">
                            <div class="step-item <?php echo $step >= 0 ? 'step-active' : ''; ?> <?php echo $step > 0 ? 'step-done' : ''; ?>">
                                <div class="step-circle">1</div>
                                <div class="step-title">阅读协议</div>
                            </div>
                            <div class="step-item <?php echo $step >= 1 ? 'step-active' : ''; ?> <?php echo $step > 1 ? 'step-done' : ''; ?>">
                                <div class="step-circle">2</div>
                                <div class="step-title">环境检查</div>
                            </div>
                            <div class="step-item <?php echo $step >= 2 ? 'step-active' : ''; ?> <?php echo $step > 2 ? 'step-done' : ''; ?>">
                                <div class="step-circle">3</div>
                                <div class="step-title">数据库配置</div>
                            </div>
                            <div class="step-item <?php echo $step >= 3 ? 'step-active' : ''; ?> <?php echo $step > 3 ? 'step-done' : ''; ?>">
                                <div class="step-circle">4</div>
                                <div class="step-title">管理员设置</div>
                            </div>
                            <div class="step-item <?php echo $step >= 4 ? 'step-active' : ''; ?>">
                                <div class="step-circle">5</div>
                                <div class="step-title">安装完成</div>
                            </div>
                        </div>
                        
                        <!-- 原有的步骤内容 -->
                        <?php if ($step == 0): ?>
                            <!-- 协议阅读界面 -->
                            <div class="license-agreement">
                                <h4>安装协议</h4>
                                <div class="border p-3 mb-3" style="height: 300px; overflow-y: auto;">
                                    <h5>使用协议</h5>
                                    <p>仔细阅读以下协议：</p>
                                    <ol>
                                        <li>本程序为开源程序，您可以遵照GPL (GNU General Public License)开源协议使用。</li>
                                        <li>使用本程序时，请遵守当地法律法规。</li>
                                        <li>本程序不含任何旨在破坏用户算机数据和获取用户隐私信息的恶意代码。</li>
                                        <li>由于使用本程序导致的任何问题，程序作者不承担任何责任。</li>
                                        <li>作者保留对本程序的最终解释权。</li>
                                        <!-- 可以根据需要添加更多协议内容 -->
                                    </ol>
                                </div>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" id="agreeCheckbox">
                                    <label class="form-check-label" for="agreeCheckbox">
                                        我已仔细阅读并同意以上协议
                                    </label>
                                </div>
                                <a href="?step=1" class="btn btn-primary disabled" id="nextStep">
                                    下一步 (<span id="countdown">3</span>)
                                </a>
                            </div>

                            <script>
                            $(function() {
                                let countdown = 3;
                                const $nextStep = $('#nextStep');
                                const $countdown = $('#countdown');
                                const $checkbox = $('#agreeCheckbox');
                                
                                function updateNextButton() {
                                    if ($checkbox.is(':checked') && countdown <= 0) {
                                        $nextStep.removeClass('disabled');
                                    } else {
                                        $nextStep.addClass('disabled');
                                    }
                                }
                                
                                // 倒计时
                                function startCountdown() {
                                    const timer = setInterval(function() {
                                        countdown--;
                                        $countdown.text(countdown);
                                        
                                        if (countdown <= 0) {
                                            clearInterval(timer);
                                            $nextStep.html('下一步');
                                            updateNextButton();
                                        }
                                    }, 1000);
                                }
                                
                                // 复选框事件
                                $checkbox.on('change', function() {
                                    updateNextButton();
                                });
                                
                                // 启动倒计时
                                startCountdown();
                            });
                            </script>

                        <?php elseif ($step == 1): ?>
                            <!-- 环境检查 -->
                            <h4>环境检查</h4>
                            <?php $requirements = checkEnvironment(); ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>检查项目</th>
                                            <th>当前状态</th>
                                            <th>检查结果</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($requirements as $item): ?>
                                        <tr>
                                            <td><?php echo $item['name']; ?></td>
                                            <td><?php echo $item['current']; ?></td>
                                            <td>
                                                <?php if ($item['status']): ?>
                                                    <span class="badge bg-success">通过</span>
                                                <?php else: ?>
                                                    <span class="badge bg-danger">未通过</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <?php 
                            $canContinue = true;
                            foreach ($requirements as $item) {
                                if ($item['status'] === false) {
                                    $canContinue = false;
                                    break;
                                }
                            }
                            ?>
                            
                            <?php if ($canContinue): ?>
                                <div class="alert alert-success">
                                    <strong>恭喜！</strong> 您的服务器配置满足安装要求。
                                </div>
                                <a href="?step=2" class="btn btn-primary">下一步</a>
                            <?php else: ?>
                                <div class="alert alert-danger">
                                    <strong>抱歉！</strong> 您的服务器配置不满足安装要求，请解决上述红色项目后继续安装。
                                </div>
                            <?php endif; ?>
                            
                        <?php elseif ($step == 2): ?>
                            <!-- 数据库配置 -->
                            <form method="post" action="?step=3" id="dbForm">
                                <div class="mb-3">
                                    <label>数据库主</label>
                                    <input type="text" class="form-control" name="db_host" value="localhost" required>
                                </div>
                                <div class="mb-3">
                                    <label>端口</label>
                                    <input type="text" class="form-control" name="db_port" value="3306" required>
                                </div>
                                <div class="mb-3">
                                    <label>数据库用户名</label>
                                    <input type="text" class="form-control" name="db_user" required>
                                </div>
                                <div class="mb-3">
                                    <label>数据库密码</label>
                                    <input type="password" class="form-control" name="db_pass">
                                </div>
                                <div class="mb-3">
                                    <label>数据库名</label>
                                    <input type="text" class="form-control" name="db_name" required>
                                </div>
                                
                                <!-- 测结果提示 -->
                                <div id="testResult" class="alert" style="display:none;"></div>
                                
                                <!-- 进度条（初始隐藏） -->
                                <div id="importProgress" class="progress mb-3" style="display:none;">
                                    <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 0%"></div>
                                </div>
                                
                                <div class="btn-group">
                                    <button type="button" class="btn btn-outline-primary" id="testDb">
                                        <i class="fas fa-database"></i> 测试连接
                                    </button>
                                    <button type="submit" class="btn btn-primary" id="nextStep" disabled>
                                        下一步 <i class="fas fa-arrow-right"></i>
                                    </button>
                                </div>
                            </form>
                            
                            <!-- 添加 Font Awesome 图标支持 -->
                            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
                            
                            <script>
                            $(function() {
                                const $form = $('#dbForm');
                                const $testBtn = $('#testDb');
                                const $nextBtn = $('#nextStep');
                                const $testResult = $('#testResult');
                                const $progress = $('#importProgress');
                                const $progressBar = $progress.find('.progress-bar');
                                
                                // 测试连接
                                $testBtn.click(function() {
                                    $testBtn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> 测试中...');
                                    $testResult.hide();
                                    
                                    $.post('index.php', $form.serialize() + '&action=test_db', function(response) {
                                        $testBtn.prop('disabled', false).html('<i class="fas fa-database"></i> 测试连');
                                        
                                        if (response.success) {
                                            $testResult
                                                .removeClass('alert-danger')
                                                .addClass('alert-success')
                                                .html('<i class="fas fa-check-circle"></i> ' + response.message)
                                                .show();
                                            $nextBtn.prop('disabled', false);
                                        } else {
                                            $testResult
                                                .removeClass('alert-success')
                                                .addClass('alert-danger')
                                                .html('<i class="fas fa-times-circle"></i> ' + response.message)
                                                .show();
                                            $nextBtn.prop('disabled', true);
                                        }
                                    }, 'json');
                                });
                                
                                // 表单提交
                                $form.on('submit', function(e) {
                                    e.preventDefault();
                                    
                                    $nextBtn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> 处理中...');
                                    $progress.show();
                                    
                                    // 模拟导入进度
                                    let progress = 0;
                                    const progressTimer = setInterval(function() {
                                        progress += Math.random() * 30;
                                        if (progress > 100) progress = 100;
                                        
                                        $progressBar.css('width', progress + '%')
                                                   .attr('aria-valuenow', progress)
                                                   .text(Math.round(progress) + '%');
                                        
                                        if (progress === 100) {
                                            clearInterval(progressTimer);
                                            // 实际提交表单
                                            $form[0].submit();
                                        }
                                    }, 500);
                                });
                                
                                // 禁用表单自动提交
                                $form.find('input').on('keypress', function(e) {
                                    return e.which !== 13;
                                });
                            });
                            </script>
                            
                        <?php elseif ($step == 3): ?>
                            <!-- 管理员账号设置 -->
                            <form method="post" id="adminForm">
                                <input type="hidden" name="action" value="install">
                                <!-- 保存数据库配置 -->
                                <?php foreach ($_POST as $key => $value): ?>
                                    <input type="hidden" name="<?php echo $key; ?>" value="<?php echo htmlspecialchars($value); ?>">
                                <?php endforeach; ?>
                                
                                <div class="mb-3">
                                    <label>管理员用户名</label>
                                    <input type="text" class="form-control" name="admin_username" required>
                                </div>
                                <div class="mb-3">
                                    <label>管理员密码</label>
                                    <input type="password" class="form-control" name="admin_password" required>
                                </div>
                                <div id="installMessage" class="alert" style="display:none;"></div>
                                <button type="submit" class="btn btn-primary" id="installBtn">完成安装</button>
                            </form>

                            <script>
                            $(function() {
                                $('#adminForm').on('submit', function(e) {
                                    e.preventDefault();
                                    const $form = $(this);
                                    const $btn = $('#installBtn');
                                    const $msg = $('#installMessage');
                                    
                                    $btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> 装中...');
                                    
                                    $.ajax({
                                        url: 'index.php',
                                        type: 'POST',
                                        data: $form.serialize(),
                                        dataType: 'json',
                                        success: function(response) {
                                            if (response.success) {
                                                window.location.href = response.redirect;
                                            } else {
                                                $msg.removeClass('alert-success').addClass('alert-danger')
                                                    .html('<i class="fas fa-times-circle"></i> ' + response.message)
                                                    .show();
                                                $btn.prop('disabled', false).text('完成安装');
                                            }
                                        },
                                        error: function() {
                                            $msg.removeClass('alert-success').addClass('alert-danger')
                                                .html('<i class="fas fa-times-circle"></i> 安装过程发生错误')
                                                .show();
                                            $btn.prop('disabled', false).text('完成安装');
                                        }
                                    });
                                });
                            });
                            </script>

                        <?php elseif ($step == 5): ?>
                            <!-- 安装完成 -->
                            <div class="text-center">
                                <div class="mb-4">
                                    <i class="fas fa-check-circle text-success" style="font-size: 64px;"></i>
                                </div>
                                <div class="alert alert-success">
                                    <h4>恭喜您，安装完成！</h4>
                                    <p>系统已经安装成功，为了安全起见，请立即删除 install 目录。</p>
                                </div>
                                <div class="mt-4">
                                    <a href="../admin/login.php" class="btn btn-primary btn-lg">
                                        <i class="fas fa-sign-in-alt"></i> 进入后台管理
                                    </a>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                    <hr class="my-4">
                    <div class="text-center text-muted">
                        <p class="mb-1">Copyright © <?php echo date('Y'); ?> 星筱科技 All Rights Reserved</p>
                        <p class="mb-1 small">Powered by 星筱科技</p>
                        <p class="mb-0 small">Version 1.0.0</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

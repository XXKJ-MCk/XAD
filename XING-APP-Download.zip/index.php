<?php
require_once(__DIR__ . '/config/database.php');
require_once(__DIR__ . '/config/common.php');

// 添加XSS防护函数
function e($str) {
    return htmlspecialchars($str, ENT_QUOTES | ENT_HTML5, 'UTF-8', true);
}

// 添加版本比较功能
function compareVersions($v1, $v2) {
    return version_compare($v1, $v2);
}

// 添加缓存机制
function getCache($key, $ttl = 300) {
    $cache_file = __DIR__ . '/cache/' . md5($key);
    if (file_exists($cache_file) && (time() - filemtime($cache_file)) < $ttl) {
        return unserialize(file_get_contents($cache_file));
    }
    return false;
}

function setCache($key, $data, $ttl = 300) {
    $cache_file = __DIR__ . '/cache/' . md5($key);
    file_put_contents($cache_file, serialize($data));
}

// 获取软件信息
$stmt = $db->query("SELECT * FROM software WHERE status = 1 ORDER BY created_at DESC LIMIT 1");
$app = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$app) {
    die('软件信息未配置');
}

// 获取该软件的线路信息
$routes = [];
if($app) {
    $stmt = $db->prepare("SELECT * FROM routes WHERE software_id = :software_id AND status = 1 ORDER BY sort_order ASC");
    $stmt->execute(['software_id' => $app['id']]);
    $routes = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// 获取用户设备类型
function getUserDevice() {
    $userAgent = $_SERVER['HTTP_USER_AGENT'];
    if (strpos($userAgent, 'Android') !== false) {
        return 'android';
    } elseif (strpos($userAgent, 'iPhone') !== false || strpos($userAgent, 'iPad') !== false) {
        return 'ios';
    } elseif (strpos($userAgent, 'Windows') !== false) {
        return 'windows';
    } elseif (strpos($userAgent, 'Macintosh') !== false) {
        return 'mac';
    }
    return 'desktop';
}

$userDevice = getUserDevice();

// 修改参数检查逻辑
$code = isset($_GET['code']) ? trim($_GET['code']) : '';
if(empty($code)) {
    // 重定向到提示页面
    header('Location: notice.php');
    exit;
}

// 查询匹配code的软件信息
$stmt = $db->prepare("SELECT * FROM software WHERE code = :code AND status = 1 LIMIT 1");
$stmt->execute(['code' => $code]);
$app = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$app) {
    $error_message = '未找到相关软件信息';
    // 如果找不到软件，获取最新的一个
    $stmt = $db->query("SELECT * FROM software WHERE status = 1 ORDER BY created_at DESC LIMIT 1");
    $app = $stmt->fetch(PDO::FETCH_ASSOC);
}

// 获取更新日志
$stmt = $db->query("SELECT version, created_at as date, update_log as logs FROM software ORDER BY created_at DESC");
$update_logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

// 处理更新日志格式
foreach ($update_logs as &$log) {
    $log['logs'] = explode("\n", trim($log['logs']));
}

?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $app['name']; ?> - 下载页面</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fancyapps/ui@5.0/dist/fancybox/fancybox.css">
    <style>
        :root {
            --primary-color: #3b82f6;
            --text-color: #333333;
            --bg-color: #ffffff;
            --border-color: #eaeaea;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
            line-height: 1.6;
            background: var(--bg-color);
            color: var(--text-color);
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }

        .app-header {
            text-align: center;
            padding: 40px 0;
        }

        .app-icon {
            width: 100px;
            height: 100px;
            border-radius: 20px;
            margin-bottom: 15px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }

        .download-section {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin: 30px 0;
            flex-wrap: wrap;
        }

        .download-group {
            position: relative;
            min-width: 200px;
        }

        .download-btn {
            width: 100%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 20px;
            background: var(--primary-color);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 500;
            cursor: pointer;
            border: none;
            font-size: 1em;
        }

        .download-btn:after {
            content: '▼';
            font-size: 0.8em;
            margin-left: 10px;
        }

        .download-menu {
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: white;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            margin-top: 5px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: none;
            z-index: 100;
        }

        .download-menu.active {
            display: block;
        }

        .download-menu a {
            display: block;
            padding: 10px 15px;
            color: var(--text-color);
            text-decoration: none;
            transition: background-color 0.2s;
        }

        .download-menu a:hover {
            background-color: #f5f5f5;
        }

        .download-menu a:not(:last-child) {
            border-bottom: 1px solid var(--border-color);
        }

        .app-info {
            background: #fff;
            border: 1px solid var(--border-color);
            padding: 20px;
            border-radius: 10px;
            margin: 20px 0;
        }

        .app-info h2 {
            font-size: 1.2em;
            margin-bottom: 15px;
            color: var(--text-color);
        }

        .features-list {
            list-style: none;
            margin: 15px 0;
        }

        .features-list li {
            padding: 8px 0 8px 20px;
            position: relative;
        }

        .features-list li:before {
            content: "•";
            position: absolute;
            left: 0;
            color: var(--primary-color);
        }

        .screenshots-container {
            margin: 20px 0;
        }

        .swiper {
            width: 100%;
            max-height: 500px;
        }

        .swiper-slide {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100%;
        }

        .swiper-slide img {
            width: 100%;
            height: 100%;
            max-height: 500px;
            border-radius: 8px;
            border: 1px solid var(--border-color);
            object-fit: contain;
        }

        .qrcode-section {
            text-align: center;
            margin: 30px 0;
        }

        .qrcode-img {
            width: 160px;
            height: 160px;
            padding: 10px;
            border: 1px solid var(--border-color);
            border-radius: 8px;
        }

        .device-notice {
            background: #f8f9fa;
            padding: 10px;
            border-radius: 8px;
            text-align: center;
            margin: 10px 0;
            font-size: 0.9em;
            color: #666;
        }

        @media (max-width: 600px) {
            .container {
                padding: 15px;
            }
            .download-group {
                width: 100%;
            }
            .app-icon {
                width: 80px;
                height: 80px;
            }
        }

        /* 添加时间线样式 */
        .timeline {
            position: relative;
            padding: 20px 0;
        }

        .timeline::before {
            content: '';
            position: absolute;
            left: 20px;
            top: 0;
            bottom: 0;
            width: 2px;
            background: var(--primary-color);
            opacity: 0.2;
        }

        .timeline-item {
            position: relative;
            padding-left: 50px;
            margin-bottom: 30px;
        }

        .timeline-item:last-child {
            margin-bottom: 0;
        }

        .timeline-item::before {
            content: '';
            position: absolute;
            left: 16px;
            top: 0;
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: var(--primary-color);
        }

        .timeline-version {
            font-weight: bold;
            color: var(--primary-color);
            margin-bottom: 5px;
        }

        .timeline-date {
            font-size: 0.9em;
            color: #666;
            margin-bottom: 10px;
        }

        .timeline-logs {
            list-style: none;
            margin: 0;
            padding: 0;
        }

        .timeline-logs li {
            position: relative;
            padding: 4px 0 4px 20px;
            color: #555;
        }

        .timeline-logs li::before {
            content: "•";
            position: absolute;
            left: 0;
            color: var(--primary-color);
            opacity: 0.7;
        }

        .screenshot-gallery {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }

        .screenshot-gallery a {
            display: block;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            transition: transform 0.2s ease;
        }

        .screenshot-gallery a:hover {
            transform: translateY(-3px);
        }

        .screenshot-gallery img {
            width: 100%;
            height: 100%;
            max-height: 300px;
            object-fit: contain;
            display: block;
        }

        @media (max-width: 600px) {
            .screenshot-gallery {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        /* 修改 Fancybox 相关样式 */
        .fancybox__content img {
            max-height: 90vh;
            object-fit: contain;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="app-header">
            <?php if (!empty($app['icon_path'])): ?>
                <img src="/<?php echo htmlspecialchars($app['icon_path']); ?>" 
                     alt="<?php echo htmlspecialchars($app['name']); ?>" 
                     class="app-icon"
                     onerror="this.src='/assets/images/default-icon.png'">
            <?php else: ?>
                <img src="/assets/images/default-icon.png" 
                     alt="<?php echo htmlspecialchars($app['name']); ?>" 
                     class="app-icon">
            <?php endif; ?>
            <h1><?php echo htmlspecialchars($app['name']); ?></h1>
            <p>版本 <?php echo htmlspecialchars($app['version']); ?></p>
        </div>

        <?php if(isset($error_message)): ?>
            <div class="alert alert-warning" style="text-align: center; padding: 10px; background: #fff3cd; color: #856404; border-radius: 4px; margin: 10px 0;">
                <?php echo $error_message; ?>
            </div>
        <?php endif; ?>

        <?php if(isset($notice_message)): ?>
            <div class="alert alert-info" style="text-align: center; padding: 10px; background: #e8f4fd; color: #004085; border-radius: 4px; margin: 10px 0;">
                <?php echo $notice_message; ?>
            </div>
        <?php endif; ?>

        <div class="download-section">
            <?php if ($userDevice === 'windows'): ?>
            <div class="download-group">
                <button class="download-btn" onclick="toggleMenu('windows-menu')">
                    Windows版本下载 (<?php echo $app['size_windows'] ?? $app['size']; ?>)
                </button>
                <?php if (!empty($routes)): ?>
                <div class="download-menu" id="windows-menu">
                    <?php foreach ($routes as $route): ?>
                    <a href="download.php?id=<?php echo $app['id']; ?>&platform=windows&route=<?php echo $route['id']; ?>" target="_blank">
                        <?php echo htmlspecialchars($route['name']); ?>
                    </a>
                    <?php endforeach; ?>
                </div>
                <?php else: ?>
                <div class="download-menu" id="windows-menu">
                    <a href="download.php?id=<?php echo $app['id']; ?>&platform=windows" target="_blank">
                        默认线路下载
                    </a>
                </div>
                <?php endif; ?>
            </div>
            <?php elseif ($userDevice === 'mac'): ?>
            <div class="download-group">
                <button class="download-btn" onclick="toggleMenu('mac-menu')">
                    Mac版本下载 (<?php echo $app['size_mac'] ?? $app['size']; ?>)
                </button>
                <?php if (!empty($routes)): ?>
                <div class="download-menu" id="mac-menu">
                    <?php foreach ($routes as $route): ?>
                    <a href="download.php?id=<?php echo $app['id']; ?>&platform=mac&route=<?php echo $route['id']; ?>" target="_blank">
                        <?php echo htmlspecialchars($route['name']); ?>
                    </a>
                    <?php endforeach; ?>
                </div>
                <?php else: ?>
                <div class="download-menu" id="mac-menu">
                    <a href="download.php?id=<?php echo $app['id']; ?>&platform=mac" target="_blank">
                        默认线路下载
                    </a>
                </div>
                <?php endif; ?>
            </div>
            <?php else: ?>
            <div class="download-group">
                <button class="download-btn" onclick="toggleMenu('default-menu')">
                    下载软件 (<?php echo $app['size']; ?>)
                </button>
                <?php if (!empty($routes)): ?>
                <div class="download-menu" id="default-menu">
                    <?php foreach ($routes as $route): ?>
                    <a href="download.php?id=<?php echo $app['id']; ?>&route=<?php echo $route['id']; ?>" target="_blank">
                        <?php echo htmlspecialchars($route['name']); ?>
                    </a>
                    <?php endforeach; ?>
                </div>
                <?php else: ?>
                <div class="download-menu" id="default-menu">
                    <a href="download.php?id=<?php echo $app['id']; ?>" target="_blank">
                        默认线路下载
                    </a>
                </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>

        <?php if ($userDevice !== 'desktop'): ?>
        <div class="device-notice">
            当前设备<?php 
            switch($userDevice) {
                case 'ios':
                    echo 'iOS';
                    break;
                case 'android':
                    echo 'Android';
                    break;
                case 'windows':
                    echo 'Windows';
                    break;
                case 'mac':
                    echo 'Mac';
                    break;
            }
            ?>
        </div>
        <?php endif; ?>

        <div class="app-info">
            <h2>应用介绍</h2>
            <p><?php echo nl2br($app['description']); ?></p>
        </div>

        <?php if (!empty($app['screenshots'])): ?>
        <div class="app-info">
            <h2>软件截图</h2>
            <div class="swiper">
                <div class="swiper-wrapper">
                    <?php 
                    $screenshots = json_decode($app['screenshots'], true);
                    if (is_array($screenshots)):
                        foreach ($screenshots as $screenshot): 
                            // 确保图片路径正确，添加网站根目录路径
                            $imagePath = '/' . ltrim($screenshot, '/');
                    ?>
                        <div class="swiper-slide">
                            <a href="<?php echo $imagePath; ?>" 
                               data-fancybox="gallery"
                               data-caption="软件截图">
                                <img src="<?php echo $imagePath; ?>" 
                                     alt="软件截图"
                                     onerror="handleImageError(this)">
                            </a>
                        </div>
                    <?php 
                        endforeach; 
                    endif;
                    ?>
                </div>
                <div class="swiper-pagination"></div>
                <div class="swiper-button-prev"></div>
                <div class="swiper-button-next"></div>
            </div>
        </div>
        <?php endif; ?>

        <div class="app-info">
            <h2>更新日志</h2>
            <div class="timeline">
                <?php foreach ($update_logs as $log): ?>
                    <div class="timeline-item">
                        <div class="timeline-version">版本 <?php echo $log['version']; ?></div>
                        <div class="timeline-date"><?php echo date('Y-m-d', strtotime($log['date'])); ?></div>
                        <ul class="timeline-logs">
                            <?php foreach ($log['logs'] as $item): ?>
                                <li><?php echo $item; ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@fancyapps/ui@5.0/dist/fancybox/fancybox.umd.js"></script>
    <script>
        new Swiper('.swiper', {
            slidesPerView: 1,
            spaceBetween: 20,
            pagination: {
                el: '.swiper-pagination',
                clickable: true
            },
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
            breakpoints: {
                640: {
                    slidesPerView: 2
                }
            },
            autoplay: {
                delay: 3000,
                disableOnInteraction: false
            },
            on: {
                init: function () {
                    const swiper = this;
                    swiper.slides.forEach(slide => {
                        const img = slide.querySelector('img');
                        if (img) {
                            img.onerror = function() {
                                img.src = 'path/to/fallback-image.jpg'; // 替换为默认图片路径
                                img.alt = '图片加载失败';
                            };
                        }
                    });
                }
            }
        });

        // 添加下菜单控制代码
        function toggleMenu(menuId) {
            // 关闭所有其他菜单
            document.querySelectorAll('.download-menu.active').forEach(menu => {
                if (menu.id !== menuId) {
                    menu.classList.remove('active');
                }
            });
            
            // 切换当前菜单
            const menu = document.getElementById(menuId);
            menu.classList.toggle('active');
        }

        // 点击页面其他地方关闭菜单
        document.addEventListener('click', function(event) {
            if (!event.target.closest('.download-group')) {
                document.querySelectorAll('.download-menu').forEach(menu => {
                    menu.classList.remove('active');
                });
            }
        });

        // 修改 Fancybox 配置
        Fancybox.bind("[data-fancybox]", {
            loop: true,
            wheel: false,
            Image: {
                zoom: true,
                fit: "contain",
                Panzoom: {
                    maxScale: 2,
                },
            },
            Toolbar: {
                display: {
                    left: ["prev"],
                    middle: ["zoomIn", "zoomOut", "toggle1to1", "rotateCCW", "rotateCW"],
                    right: ["next"],
                    top: ["close"],
                },
            },
            protected: true,
            showLoading: true,
            preload: 1,
            animated: true,
            dragToClose: false,
            click: "toggleZoom",
            dblclick: "toggleZoom",
            keyboard: {
                Escape: "close",
                Delete: "close",
                Backspace: "close",
                PageUp: "next",
                PageDown: "prev",
                ArrowUp: "prev",
                ArrowDown: "next",
                ArrowRight: "next",
                ArrowLeft: "prev",
            },
            on: {
                initLayout: (fancybox) => {
                    // 自定义布局初始化
                },
                "error": (fancybox, slide, error) => {
                    console.error("Fancybox error:", error);
                    slide.$content.innerHTML = `
                        <div style="text-align: center; padding: 20px;">
                            <p>图片加载失败</p>
                            <small>请检查图片路径是否正确</small>
                        </div>`;
                }
            }
        });

        // 更新图片错误处理函数
        function handleImageError(img) {
            console.error('Image load error:', img.src);
            img.onerror = null; // 防止循环调用
            img.src = '/assets/images/image-error.png'; // 使用绝对路径
            img.alt = '图片加载失败';
        }

        // 添加调试代码
        document.querySelectorAll('[data-fancybox="gallery"]').forEach(el => {
            console.log('Gallery item href:', el.getAttribute('href'));
        });
    </script>
</body>
</html>

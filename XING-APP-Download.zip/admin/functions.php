<?php
/**
 * 检查管理员权限
 * 如果未登录或会话过期，将重定向到登录页面
 */
function checkPermission() {
    // 启动会话（如果还没启动）
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    // 检查是否登录
    if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
        // 未登录，重定向到登录页面
        header('Location: login.php');
        exit('请先登录');
    }
    
    // 检查会话是否过期
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > 3600)) {
        // 如果最后活动时间超过1小时，销毁会话
        session_unset();
        session_destroy();
        header('Location: login.php');
        exit('会话已过期，请重新登录');
    }
    
    // 更新最后活动时间
    $_SESSION['last_activity'] = time();
}

/**
 * 格式化文件大小
 * @param int $bytes 字节数
 * @return string 格式化后的大小
 */
function formatFileSize($bytes) {
    if ($bytes === 0) return '0 Bytes';
    $k = 1024;
    $sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    $i = floor(log($bytes) / log($k));
    return round($bytes / pow($k, $i), 2) . ' ' . $sizes[$i];
}

/**
 * 获取客户端IP地址
 */
function getClientIP() {
    $ip_headers = [
        'HTTP_CLIENT_IP',
        'HTTP_X_FORWARDED_FOR',
        'HTTP_X_FORWARDED',
        'HTTP_X_CLUSTER_CLIENT_IP',
        'HTTP_FORWARDED_FOR',
        'HTTP_FORWARDED',
        'REMOTE_ADDR'
    ];
    
    foreach ($ip_headers as $header) {
        if (!empty($_SERVER[$header])) {
            $ip = trim($_SERVER[$header]);
            if (filter_var($ip, FILTER_VALIDATE_IP)) {
                return $ip;
            }
        }
    }
    
    return '0.0.0.0';
}

/**
 * 记录操作日志
 */
function logAdminOperation($action, $description = '') {
    global $db;
    
    try {
        $stmt = $db->prepare("INSERT INTO operation_logs (user_id, action, ip, user_agent, description, created_at) 
                             VALUES (:user_id, :action, :ip, :user_agent, :description, NOW())");
                             
        $stmt->execute([
            'user_id' => $_SESSION['admin_id'],
            'action' => $action,
            'ip' => getClientIP(),
            'user_agent' => $_SERVER['HTTP_USER_AGENT'],
            'description' => $description
        ]);
        
        return true;
    } catch (PDOException $e) {
        error_log("Failed to log operation: " . $e->getMessage());
        return false;
    }
}

/**
 * 安全过滤输入
 */
function safeInput($str) {
    return htmlspecialchars(trim($str), ENT_QUOTES, 'UTF-8');
}

/**
 * 生成随机字符串
 */
function generateRandomString($length = 32) {
    try {
        return bin2hex(random_bytes($length / 2));
    } catch (Exception $e) {
        return substr(str_shuffle(str_repeat('0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', $length)), 0, $length);
    }
}

/**
 * 检查文件类型是否允许
 */
function isAllowedFileType($filename) {
    $allowed_extensions = array_keys(ALLOWED_FILE_TYPES);
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    return in_array($ext, $allowed_extensions);
} 
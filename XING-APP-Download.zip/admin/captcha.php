<?php
session_start();

// 设置验证码图片的宽度和高度
$width = 100;
$height = 38;

// 创建图片
$image = imagecreatetruecolor($width, $height);

// 设置背景色
$bg_color = imagecolorallocate($image, 255, 255, 255);
imagefill($image, 0, 0, $bg_color);

// 生成随机验证码
$chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
$length = 4;
$code = '';
for ($i = 0; $i < $length; $i++) {
    $code .= $chars[mt_rand(0, strlen($chars) - 1)];
}

// 保存验证码到session
$_SESSION['captcha'] = $code;

// 添加干扰线
for ($i = 0; $i < 6; $i++) {
    $color = imagecolorallocate($image, mt_rand(100, 200), mt_rand(100, 200), mt_rand(100, 200));
    imageline($image, mt_rand(0, $width), mt_rand(0, $height), mt_rand(0, $width), mt_rand(0, $height), $color);
}

// 添加干扰点
for ($i = 0; $i < 50; $i++) {
    $color = imagecolorallocate($image, mt_rand(100, 200), mt_rand(100, 200), mt_rand(100, 200));
    imagesetpixel($image, mt_rand(0, $width), mt_rand(0, $height), $color);
}

// 添加验证码文字
for ($i = 0; $i < $length; $i++) {
    $color = imagecolorallocate($image, mt_rand(0, 100), mt_rand(0, 100), mt_rand(0, 100));
    $font_size = mt_rand(14, 18);
    $x = ($i * $width / $length) + mt_rand(5, 10);
    $y = mt_rand($height/2, $height-10);
    imagestring($image, $font_size, $x, $y, $code[$i], $color);
}

// 输出图片
header('Content-Type: image/png');
imagepng($image);
imagedestroy($image);
<?php
require_once __DIR__ . '/../init.php';
check_admin_login();

error_reporting(E_ALL);
ini_set('display_errors', 1);

error_log('API被调用: ' . $_SERVER['REQUEST_METHOD'] . ' ' . ($_GET['action'] ?? 'no action'));

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $action = $_GET['action'] ?? '';
    
    if ($action === 'get' && isset($_GET['id'])) {
        $id = (int)$_GET['id'];
        error_log('请求获取软件ID: ' . $id);
        
        try {
            $stmt = $db->prepare("SELECT * FROM software WHERE id = ?");
            $stmt->execute([$id]);
            $software = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($software) {
                header('Content-Type: application/json');
                header('Cache-Control: no-cache, must-revalidate');
                echo json_encode($software);
                error_log('成功返回软件数据');
            } else {
                http_response_code(404);
                echo json_encode(['error' => '软件不存在']);
                error_log('软件不存在: ' . $id);
            }
        } catch (Exception $e) {
            error_log('数据库错误: ' . $e->getMessage());
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
    }
} 
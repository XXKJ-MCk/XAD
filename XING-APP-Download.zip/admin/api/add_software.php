<?php
require_once '../init.php';

// 检查登录状态
check_admin_login();

try {
    // 处理图片上传
    $icon_path = '';
    if (isset($_FILES['software_icon']) && $_FILES['software_icon']['size'] > 0) {
        $upload_dir = '../uploads/icons/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        $file = $_FILES['software_icon'];
        $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $allowed_exts = ['jpg', 'jpeg', 'png', 'gif'];
        
        if (in_array($file_ext, $allowed_exts)) {
            $icon_name = uniqid() . '_icon.' . $file_ext;
            $icon_path = $upload_dir . $icon_name;
            
            if (!move_uploaded_file($file['tmp_name'], $icon_path)) {
                throw new Exception('图标上传失败');
            }
        } else {
            throw new Exception('不支持的图片格式');
        }
    }

    // 处理截图上传
    $screenshots = [];
    if (isset($_FILES['software_screenshots'])) {
        $upload_dir = '../uploads/screenshots/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        foreach ($_FILES['software_screenshots']['tmp_name'] as $key => $tmp_name) {
            if ($_FILES['software_screenshots']['size'][$key] > 0) {
                $file_ext = strtolower(pathinfo($_FILES['software_screenshots']['name'][$key], PATHINFO_EXTENSION));
                $allowed_exts = ['jpg', 'jpeg', 'png', 'gif'];
                
                if (in_array($file_ext, $allowed_exts)) {
                    $screenshot_name = uniqid() . '_screenshot.' . $file_ext;
                    $screenshot_path = $upload_dir . $screenshot_name;
                    
                    if (move_uploaded_file($tmp_name, $screenshot_path)) {
                        $screenshots[] = $screenshot_path;
                    }
                }
            }
        }
    }

    // 生成唯一的软件编码
    $code = substr(md5(uniqid()), 0, 8);
    
    // 检查编码是否已存在
    $check_stmt = $db->prepare("SELECT id FROM software WHERE code = ?");
    $check_stmt->execute([$code]);
    while ($check_stmt->fetch()) {
        $code = substr(md5(uniqid()), 0, 8);
        $check_stmt->execute([$code]);
    }

    // 插入数据
    $stmt = $db->prepare("INSERT INTO software (
        name, version, description, platform, update_log,
        release_date, size, icon_path, screenshots, file_path, code
    ) VALUES (
        ?, ?, ?, ?, ?,
        ?, ?, ?, ?, ?, ?
    )");

    $release_date = !empty($_POST['release_date']) ? $_POST['release_date'] : null;

    $stmt->execute([
        $_POST['name'],
        $_POST['version'],
        $_POST['description'],
        $_POST['platform'],
        $_POST['update_log'],
        $release_date,
        $_POST['size'],
        $icon_path,
        json_encode($screenshots),
        '',
        $code
    ]);

    // 返回成功响应
    echo json_encode([
        'success' => true,
        'message' => '软件添加成功'
    ]);

} catch (Exception $e) {
    // 返回错误响应
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
} 
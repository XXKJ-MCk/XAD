<?php
require_once '../init.php';

// 检查登录状态
check_admin_login();

try {
    // 获取软件信息
    $stmt = $db->prepare("SELECT icon_path, screenshots FROM software WHERE id = ?");
    $stmt->execute([$_POST['id']]);
    $software = $stmt->fetch();
    
    if (!$software) {
        throw new Exception('软件不存在');
    }
    
    // 处理图标上传
    $icon_path = $software['icon_path'];
    if (isset($_FILES['software_icon']) && $_FILES['software_icon']['size'] > 0) {
        $upload_dir = '../uploads/icons/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        $file = $_FILES['software_icon'];
        $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $allowed_exts = ['jpg', 'jpeg', 'png', 'gif'];
        
        if (in_array($file_ext, $allowed_exts)) {
            // 删除旧图标
            if (!empty($software['icon_path']) && file_exists($software['icon_path'])) {
                unlink($software['icon_path']);
            }
            
            $icon_name = uniqid() . '_icon.' . $file_ext;
            $icon_path = $upload_dir . $icon_name;
            
            if (!move_uploaded_file($file['tmp_name'], $icon_path)) {
                throw new Exception('图标上传失败');
            }
        } else {
            throw new Exception('不支持的图片格式');
        }
    }
    
    // 处理截图上传
    $screenshots = !empty($software['screenshots']) ? json_decode($software['screenshots'], true) : [];
    if (isset($_FILES['software_screenshots'])) {
        $upload_dir = '../uploads/screenshots/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        foreach ($_FILES['software_screenshots']['tmp_name'] as $key => $tmp_name) {
            if ($_FILES['software_screenshots']['size'][$key] > 0) {
                $file_ext = strtolower(pathinfo($_FILES['software_screenshots']['name'][$key], PATHINFO_EXTENSION));
                $allowed_exts = ['jpg', 'jpeg', 'png', 'gif'];
                
                if (in_array($file_ext, $allowed_exts)) {
                    $screenshot_name = uniqid() . '_screenshot.' . $file_ext;
                    $screenshot_path = $upload_dir . $screenshot_name;
                    
                    if (move_uploaded_file($tmp_name, $screenshot_path)) {
                        $screenshots[] = $screenshot_path;
                    }
                }
            }
        }
    }
    
    // 处理要删除的截图
    if (!empty($_POST['removed_screenshots'])) {
        $removed = json_decode($_POST['removed_screenshots'], true);
        foreach ($removed as $path) {
            if (file_exists($path)) {
                unlink($path);
            }
            $screenshots = array_diff($screenshots, [$path]);
        }
    }

    // 更新软件信息
    $stmt = $db->prepare("UPDATE software SET 
        name = ?, 
        version = ?, 
        description = ?, 
        platform = ?, 
        update_log = ?,
        size = ?,
        release_date = ?,
        icon_path = ?,
        screenshots = ?,
        updated_at = CURRENT_TIMESTAMP
        WHERE id = ?");
        
    $release_date = !empty($_POST['release_date']) ? $_POST['release_date'] : null;
    
    $stmt->execute([
        $_POST['name'],
        $_POST['version'],
        $_POST['description'],
        $_POST['platform'],
        $_POST['update_log'],
        $_POST['size'],
        $release_date,
        $icon_path,
        json_encode(array_values($screenshots)),
        $_POST['id']
    ]);
    
    // 返回成功响应
    echo json_encode([
        'success' => true,
        'message' => '软件更新成功'
    ]);

} catch (Exception $e) {
    // 返回错误响应
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
} 
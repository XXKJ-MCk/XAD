<?php
session_start();
define('IN_ADMIN', true);

// 检查管理员是否登录
if (!isset($_SESSION['admin_logged_in'])) {
    die(json_encode(['success' => false, 'message' => '未登录或会话已过期']));
}

try {
    // 清除PHP操作缓存（如果启用）
    if (function_exists('opcache_reset')) {
        opcache_reset();
    }
    
    // 清除文件缓存目录
    $cache_dir = __DIR__ . '/../cache/';
    if (is_dir($cache_dir)) {
        $files = glob($cache_dir . '*');
        foreach ($files as $file) {
            if (is_file($file)) {
                unlink($file);
            }
        }
    }
    
    // 清除会话缓存
    session_write_close();
    
    // 返回成功响应
    echo json_encode(['success' => true, 'message' => '缓存已成功清除']);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} 
<?php
require_once(__DIR__ . '/../../config/version.php');
require_once(__DIR__ . '/../../config/database.php');

// 获取统计数据
function get_dashboard_stats($db = null) {
    // 确保常量已定义
    $version = defined('SYSTEM_VERSION') ? SYSTEM_VERSION : '1.0.0';
    $build = defined('SYSTEM_BUILD') ? SYSTEM_BUILD : date('Ymd');
    
    $stats = [
        'version' => $version,
        'build' => $build,
        'software_count' => 0,
        'download_count' => 0,
        'route_count' => 0
    ];
    
    // 如果数据库连接无效，直接返回默认值
    if (!$db) {
        error_log("Database connection is not available");
        return $stats;
    }
    
    try {
        // 使用预处理语句防止SQL注入
        $stats['software_count'] = get_table_count($db, 'software', 'status = 1');
        $stats['download_count'] = get_total_downloads($db);
        $stats['route_count'] = get_table_count($db, 'routes', 'status = 1');
    } catch (PDOException $e) {
        error_log("Dashboard stats error: " . $e->getMessage());
    }
    
    return $stats;
}

// 添加辅助函数
function get_table_count($db, $table, $where = '1') {
    $stmt = $db->prepare("SELECT COUNT(*) FROM `$table` WHERE $where");
    $stmt->execute();
    return (int)$stmt->fetchColumn();
}

function get_total_downloads($db) {
    $stmt = $db->prepare("SELECT COALESCE(SUM(download_count), 0) FROM software");
    $stmt->execute();
    return (int)$stmt->fetchColumn();
}

// 获取数据库连接
try {
    if (!isset($db) || !($db instanceof PDO)) {
        require_once(__DIR__ . '/../../config/database.php');
    }
    
    if (!$db) {
        throw new Exception("Database connection not available");
    }
} catch (Exception $e) {
    error_log("Dashboard database error: " . $e->getMessage());
    $db = null;
}

$stats = get_dashboard_stats($db);

// 获取远程公告
function get_remote_announcements() {
    $announcements = [
        'status' => 'success',
        'data' => []
    ];
    
    try {
        // 这里替换为实际的远程公告API地址
        $api_url = 'http://www.xxkj.pro/api/XAD.php';
        
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $api_url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 5,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_USERAGENT => 'AdminPanel/1.0'
        ]);
        
        $response = curl_exec($ch);
        
        if ($response === false) {
            throw new Exception(curl_error($ch));
        }
        
        $data = json_decode($response, true);
        if (json_last_error() === JSON_ERROR_NONE) {
            $announcements['data'] = $data;
        }
        
        curl_close($ch);
    } catch (Exception $e) {
        error_log("Failed to fetch announcements: " . $e->getMessage());
        // 当无法获取远程公告时，显示默认公告
        $announcements['data'] = [
            [
                'title' => '系统公告',
                'content' => '欢迎使用管理系统！',
                'type' => 'info',
                'date' => date('Y-m-d')
            ]
        ];
    }
    
    return $announcements;
}

$announcements = get_remote_announcements();

// 在获取图表数据之前添加以下函数
function get_date_range($period = 'week') {
    $end_date = date('Y-m-d');
    if ($period == 'week') {
        $start_date = date('Y-m-d', strtotime('-6 days')); // 最近7天
    } else {
        $start_date = date('Y-m-d', strtotime('-29 days')); // 最近30天
    }
    return [$start_date, $end_date];
}

// 获取今日访问量
$today_visits_sql = "
    SELECT COUNT(DISTINCT ip) as count
    FROM front_visits 
    WHERE DATE(visit_time) = CURDATE()
";
try {
    $today_visits = $db->query($today_visits_sql)->fetchColumn();
} catch (PDOException $e) {
    error_log("Error getting today's visits: " . $e->getMessage());
    $today_visits = 0; // 如果查询失败，设置默认值为0
}

// 获取初始数据（默认显示周数据）
list($start_date, $end_date) = get_date_range('week');

// 获取下载趋势数据
$download_sql = "
    SELECT 
        DATE(download_time) as date,
        COUNT(*) as count
    FROM download_logs 
    WHERE download_time >= :start_date
    AND download_time <= :end_date
    GROUP BY DATE(download_time)
    ORDER BY date ASC
";

$stmt = $db->prepare($download_sql);
$stmt->execute([
    ':start_date' => $start_date,
    ':end_date' => $end_date . ' 23:59:59'
]);
$download_data = $stmt->fetchAll();

// 获取访问趋势数据
$visit_sql = "
    SELECT 
        DATE(visit_time) as date,
        COUNT(DISTINCT ip) as count
    FROM front_visits 
    WHERE visit_time >= :start_date
    AND visit_time <= :end_date
    GROUP BY DATE(visit_time)
    ORDER BY date ASC
";

$stmt = $db->prepare($visit_sql);
$stmt->execute([
    ':start_date' => $start_date,
    ':end_date' => $end_date . ' 23:59:59'
]);
$visit_data = $stmt->fetchAll();

// 处理数据，填充没有数据的日期
$dates = [];
$downloads = [];
$visits = [];

$current = strtotime($start_date);
$end = strtotime($end_date);

while ($current <= $end) {
    $date = date('Y-m-d', $current);
    $dates[] = date('m-d', $current); // 只显示月-日
    $downloads[$date] = 0;
    $visits[$date] = 0;
    $current = strtotime('+1 day', $current);
}

foreach ($download_data as $row) {
    $downloads[$row['date']] = (int)$row['count'];
}

foreach ($visit_data as $row) {
    $visits[$row['date']] = (int)$row['count'];
}

// 处理图表数据为 JSON 格式
$chart_data = [
    'week' => [
        'dates' => $dates,
        'downloads' => array_values($downloads),
        'visits' => array_values($visits)
    ]
];

// 获取月数据
list($start_date, $end_date) = get_date_range('month');

// 重复上面的查询过程，但使用月范围
$stmt = $db->prepare($download_sql);
$stmt->execute([
    ':start_date' => $start_date,
    ':end_date' => $end_date . ' 23:59:59'
]);
$download_data = $stmt->fetchAll();

$stmt = $db->prepare($visit_sql);
$stmt->execute([
    ':start_date' => $start_date,
    ':end_date' => $end_date . ' 23:59:59'
]);
$visit_data = $stmt->fetchAll();

// 处理月数据
$dates = [];
$downloads = [];
$visits = [];

$current = strtotime($start_date);
$end = strtotime($end_date);

while ($current <= $end) {
    $date = date('Y-m-d', $current);
    $dates[] = date('m-d', $current);
    $downloads[$date] = 0;
    $visits[$date] = 0;
    $current = strtotime('+1 day', $current);
}

foreach ($download_data as $row) {
    $downloads[$row['date']] = (int)$row['count'];
}

foreach ($visit_data as $row) {
    $visits[$row['date']] = (int)$row['count'];
}

// 添加月数据到图表数据
$chart_data['month'] = [
    'dates' => $dates,
    'downloads' => array_values($downloads),
    'visits' => array_values($visits)
];

$chart_json = json_encode($chart_data);
?>

<div class="container-fluid dashboard">
    <!-- 欢迎信息 -->
    <div class="welcome-section mb-4">
        <h1 class="welcome-title">欢迎回来！</h1>
        <p class="welcome-subtitle">这里是您的管理控制台概览</p>
    </div>

    <div class="row">
        <!-- 版本信息卡片 -->
        <div class="col-md-6 col-lg-3 mb-4">
            <div class="card dashboard-card">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="card-icon rounded-circle d-flex align-items-center justify-content-center bg-primary-light">
                            <i class="bi bi-info-circle text-primary"></i>
                        </div>
                        <div class="ps-3">
                            <h6 class="card-subtitle">系统版本</h6>
                            <h2 class="card-title mb-0"><?php echo $stats['version']; ?></h2>
                            <div class="card-info">
                                <span class="badge bg-primary-light text-primary">
                                    Build <?php echo $stats['build']; ?>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- 软件数量卡片 -->
        <div class="col-md-6 col-lg-3 mb-4">
            <div class="card dashboard-card">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="card-icon rounded-circle d-flex align-items-center justify-content-center bg-success-light">
                            <i class="bi bi-box text-success"></i>
                        </div>
                        <div class="ps-3">
                            <h6 class="card-subtitle">软件数量</h6>
                            <h2 class="card-title mb-0 counter"><?php echo number_format($stats['software_count']); ?></h2>
                            <div class="card-info">
                                <span class="badge bg-success-light text-success">
                                    活跃软件
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- 下载统计卡片 -->
        <div class="col-md-6 col-lg-3 mb-4">
            <div class="card dashboard-card">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="card-icon rounded-circle d-flex align-items-center justify-content-center bg-info-light">
                            <i class="bi bi-download text-info"></i>
                        </div>
                        <div class="ps-3">
                            <h6 class="card-subtitle">总下载量</h6>
                            <h2 class="card-title mb-0 counter"><?php echo number_format($stats['download_count']); ?></h2>
                            <div class="card-info">
                                <span class="badge bg-info-light text-info">
                                    累计下载
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- 线路数量卡片 -->
        <div class="col-md-6 col-lg-3 mb-4">
            <div class="card dashboard-card">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="card-icon rounded-circle d-flex align-items-center justify-content-center bg-warning-light">
                            <i class="bi bi-diagram-3 text-warning"></i>
                        </div>
                        <div class="ps-3">
                            <h6 class="card-subtitle">线路数量</h6>
                            <h2 class="card-title mb-0 counter"><?php echo number_format($stats['route_count']); ?></h2>
                            <div class="card-info">
                                <span class="badge bg-warning-light text-warning">
                                    活跃线路
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 添加公告板块 -->
    <div class="row mt-4">
        <div class="col-12">
            <div class="card dashboard-card announcement-card">
                <div class="card-header bg-transparent">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">
                            <i class="bi bi-megaphone me-2"></i>
                            系统公告
                        </h5>
                        <button class="btn btn-sm btn-outline-primary refresh-announcements">
                            <i class="bi bi-arrow-clockwise"></i>
                            刷新
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <div class="announcement-list">
                        <?php if (!empty($announcements['data'])): ?>
                            <?php foreach ($announcements['data'] as $announcement): ?>
                                <div class="announcement-item">
                                    <div class="announcement-icon">
                                        <i class="bi bi-bell text-<?php echo $announcement['type'] ?? 'info'; ?>"></i>
                                    </div>
                                    <div class="announcement-content">
                                        <h6 class="announcement-title">
                                            <?php echo htmlspecialchars($announcement['title']); ?>
                                        </h6>
                                        <p class="announcement-text">
                                            <?php echo htmlspecialchars($announcement['content']); ?>
                                        </p>
                                        <small class="announcement-date text-muted">
                                            <?php echo $announcement['date']; ?>
                                        </small>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="text-center text-muted py-4">
                                <i class="bi bi-inbox-fill mb-2" style="font-size: 2rem;"></i>
                                <p>暂无公告</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 在公告板块后添加图表板块 -->
    <div class="row mt-4">
        <!-- 下载趋势图表 -->
        <div class="col-md-6">
            <div class="card dashboard-card">
                <div class="card-header bg-transparent">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">
                            <i class="bi bi-graph-up me-2"></i>
                            下载趋势
                        </h5>
                        <div class="btn-group">
                            <button class="btn btn-sm btn-outline-primary active" data-period="week" onclick="updateDownloadChart(this)">
                                周
                            </button>
                            <button class="btn btn-sm btn-outline-primary" data-period="month" onclick="updateDownloadChart(this)">
                                月
                            </button>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <canvas id="downloadChart" height="300"></canvas>
                </div>
            </div>
        </div>

        <!-- 访问趋势图表 -->
        <div class="col-md-6">
            <div class="card dashboard-card">
                <div class="card-header bg-transparent">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">
                            <i class="bi bi-bar-chart me-2"></i>
                            前台访问趋势
                            <small class="text-muted ms-2">今日访问: <?php echo number_format($today_visits); ?></small>
                        </h5>
                        <div class="btn-group">
                            <button class="btn btn-sm btn-outline-primary active" data-period="week" onclick="updateVisitChart(this)">
                                周
                            </button>
                            <button class="btn btn-sm btn-outline-primary" data-period="month" onclick="updateVisitChart(this)">
                                月
                            </button>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <canvas id="visitChart" height="300"></canvas>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* 仪表盘整体样式 */
.dashboard {
    padding: 1.5rem;
}

/* 欢迎区域样式 */
.welcome-section {
    padding: 1rem 0 2rem;
}

.welcome-title {
    font-size: 2rem;
    color: var(--text-color);
    margin-bottom: 0.5rem;
    font-weight: 600;
}

.welcome-subtitle {
    color: #6c757d;
    font-size: 1.1rem;
    margin-bottom: 0;
}

/* 卡片样式优化 */
.dashboard-card {
    border: none;
    border-radius: 15px;
    box-shadow: 0 0 20px rgba(1, 41, 112, 0.1);
    transition: all 0.3s ease;
    overflow: hidden;
}

.dashboard-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 24px rgba(1, 41, 112, 0.15);
}

.card-body {
    padding: 1.5rem;
}

.card-icon {
    width: 64px;
    height: 64px;
    flex-shrink: 0;
}

.card-icon i {
    font-size: 32px;
}

.card-subtitle {
    color: #6c757d;
    font-size: 0.875rem;
    margin-bottom: 0.5rem;
    font-weight: 500;
}

.card-title {
    font-size: 1.75rem;
    font-weight: 600;
    color: var(--text-color);
}

.card-info {
    margin-top: 0.5rem;
}

/* 背景色定义 */
.bg-primary-light {
    background-color: rgba(65, 84, 241, 0.1);
}

.bg-success-light {
    background-color: rgba(46, 202, 106, 0.1);
}

.bg-info-light {
    background-color: rgba(65, 84, 241, 0.1);
}

.bg-warning-light {
    background-color: rgba(255, 119, 29, 0.1);
}

/* 徽章样式 */
.badge {
    padding: 0.5em 1em;
    font-weight: 500;
    border-radius: 30px;
    font-size: 0.75rem;
}

/* 数字计数动画 */
.counter {
    opacity: 0;
    animation: fadeInUp 0.5s ease forwards;
}

/* 动画效果 */
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* 响应调整 */
@media (max-width: 768px) {
    .welcome-title {
        font-size: 1.5rem;
    }
    
    .card-title {
        font-size: 1.5rem;
    }
    
    .card-icon {
        width: 48px;
        height: 48px;
    }
    
    .card-icon i {
        font-size: 24px;
    }
}

/* 公告卡片样式 */
.announcement-card {
    margin-bottom: 2rem;
}

.announcement-card .card-header {
    padding: 1rem 1.5rem;
    border-bottom: 1px solid rgba(0,0,0,.05);
}

.announcement-list {
    max-height: 400px;
    overflow-y: auto;
}

.announcement-item {
    display: flex;
    padding: 1rem 0;
    border-bottom: 1px solid rgba(0,0,0,.05);
}

.announcement-item:last-child {
    border-bottom: none;
}

.announcement-icon {
    flex-shrink: 0;
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: rgba(65, 84, 241, 0.1);
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 1rem;
}

.announcement-icon i {
    font-size: 1.2rem;
}

.announcement-content {
    flex-grow: 1;
}

.announcement-title {
    margin-bottom: 0.5rem;
    color: var(--text-color);
    font-weight: 600;
}

.announcement-text {
    color: #6c757d;
    margin-bottom: 0.5rem;
    line-height: 1.5;
}

.announcement-date {
    display: block;
    font-size: 0.875rem;
}

/* 滚动条美化 */
.announcement-list::-webkit-scrollbar {
    width: 6px;
}

.announcement-list::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 3px;
}

.announcement-list::-webkit-scrollbar-thumb {
    background: #ccc;
    border-radius: 3px;
}

.announcement-list::-webkit-scrollbar-thumb:hover {
    background: #999;
}

/* 刷新按钮动画 */
@keyframes spin {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}

.refresh-announcements i {
    transition: transform 0.3s ease;
}

.refresh-announcements.loading i {
    animation: spin 1s linear infinite;
}

.btn-group .btn {
    padding: 0.25rem 1rem;
    font-size: 0.875rem;
}

.btn-group .btn.active {
    background-color: var(--primary-color);
    color: #fff;
    border-color: var(--primary-color);
}

.card-header h5 {
    font-size: 1.1rem;
    font-weight: 600;
}

.chart-container {
    position: relative;
    height: 300px;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // 添加进入动画
    const cards = document.querySelectorAll('.dashboard-card');
    cards.forEach((card, index) => {
        card.style.animation = `fadeInUp 0.5s ease forwards ${index * 0.1}s`;
    });

    // 数字计数动画
    const counters = document.querySelectorAll('.counter');
    counters.forEach(counter => {
        counter.style.opacity = 1;
    });

    // 添加公告刷新功能
    const refreshBtn = document.querySelector('.refresh-announcements');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', function() {
            const btn = this;
            btn.classList.add('loading');
            btn.disabled = true;

            // 这里添加实际的刷新逻辑
            fetch('get_announcements.php')
                .then(response => response.json())
                .then(data => {
                    // 更新告内容
                    const announcementList = document.querySelector('.announcement-list');
                    // 处理返回的数据并更新DOM
                })
                .catch(error => {
                    console.error('Failed to refresh announcements:', error);
                })
                .finally(() => {
                    setTimeout(() => {
                        btn.classList.remove('loading');
                        btn.disabled = false;
                    }, 500);
                });
        });
    }
});
</script>

<!-- 在 </body> 前添加 Chart.js 库 -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<!-- 添加图表相关脚本 -->
<script>
// 获取PHP传递的数据
const chartData = <?php echo $chart_json; ?>;

// 图表配置和数据
const chartConfig = {
    type: 'line',
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                display: false
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                grid: {
                    drawBorder: false
                }
            },
            x: {
                grid: {
                    display: false
                }
            }
        },
        elements: {
            line: {
                tension: 0.4
            },
            point: {
                radius: 4,
                hoverRadius: 6
            }
        }
    }
};

// 初始化下载趋势图表
const downloadCtx = document.getElementById('downloadChart').getContext('2d');
const downloadChart = new Chart(downloadCtx, {
    ...chartConfig,
    data: {
        labels: chartData.week.dates,
        datasets: [{
            label: '下载量',
            data: chartData.week.downloads,
            borderColor: '#4154f1',
            backgroundColor: 'rgba(65, 84, 241, 0.1)',
            fill: true
        }]
    }
});

// 初始化访问趋势图表
const visitCtx = document.getElementById('visitChart').getContext('2d');
const visitChart = new Chart(visitCtx, {
    ...chartConfig,
    data: {
        labels: chartData.week.dates,
        datasets: [{
            label: '访问量',
            data: chartData.week.visits,
            borderColor: '#2eca6a',
            backgroundColor: 'rgba(46, 202, 106, 0.1)',
            fill: true
        }]
    }
});

// 更新下载趋势图表
function updateDownloadChart(btn) {
    const period = btn.dataset.period;
    
    // 更新按钮状态
    btn.parentElement.querySelectorAll('.btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');

    // 更新图表数据
    downloadChart.data.labels = chartData[period].dates;
    downloadChart.data.datasets[0].data = chartData[period].downloads;
    downloadChart.update();
}

// 更新访问趋势图表
function updateVisitChart(btn) {
    const period = btn.dataset.period;
    
    // 更新按钮状态
    btn.parentElement.querySelectorAll('.btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');

    // 更新图表数据
    visitChart.data.labels = chartData[period].dates;
    visitChart.data.datasets[0].data = chartData[period].visits;
    visitChart.update();
}

// 初始加载图表数据
document.addEventListener('DOMContentLoaded', function() {
    // 图表已经在上面初始化，不需要额外的加载代码
});
</script> 
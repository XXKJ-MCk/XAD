<?php
// 检查是否有权限访问
if (!defined('IN_ADMIN')) {
    exit('Access Denied');
}

// 获取网站根目录URL（修改为更可靠的方式）
$script_name = dirname($_SERVER['SCRIPT_NAME']);
$base_url = rtrim(str_replace('\\', '/', $script_name), '/admin');

// 处理软件删除
if (isset($_POST['delete']) && isset($_POST['id'])) {
    try {
        // 获取软件信息以删除相关文件
        $stmt = $db->prepare("SELECT icon_path, file_path, screenshots FROM software WHERE id = ?");
        $stmt->execute([$_POST['id']]);
        $software = $stmt->fetch();
        
        // 删除图标文件
        if ($software['icon_path']) {
            $icon_file = __DIR__ . '/../../' . $software['icon_path'];
            if (file_exists($icon_file)) {
                unlink($icon_file);
            }
        }
        
        // 删除软件文件
        if ($software['file_path']) {
            $software_file = __DIR__ . '/../../' . $software['file_path'];
            if (file_exists($software_file)) {
                unlink($software_file);
            }
        }
        
        // 删除截图文件
        if ($software['screenshots']) {
            $screenshots = json_decode($software['screenshots'], true);
            foreach ($screenshots as $screenshot) {
                $screenshot_file = __DIR__ . '/../../' . $screenshot;
                if (file_exists($screenshot_file)) {
                    unlink($screenshot_file);
                }
            }
        }

        // 删除数据库记录
        $stmt = $db->prepare("DELETE FROM software WHERE id = ?");
        $stmt->execute([$_POST['id']]);
        $success = "删除成功";
    } catch (PDOException $e) {
        $error = "删除失败: " . $e->getMessage();
    }
}

// 获取软件列表
$stmt = $db->query("SELECT * FROM software ORDER BY created_at DESC");
$software_list = $stmt->fetchAll();

// 获取文件大小的辅助函数
function formatFileSize($path) {
    if (!file_exists($path)) return 'N/A';
    $size = filesize($path);
    $units = array('B', 'KB', 'MB', 'GB', 'TB');
    $power = $size > 0 ? floor(log($size, 1024)) : 0;
    return number_format($size / pow(1024, $power), 2, '.', ',') . ' ' . $units[$power];
}
?>

<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <h4 class="mb-0">软件管理</h4>
                <a href="?page=software_edit" class="btn btn-primary">
                    <i class="bi bi-plus-lg"></i> 添加软件
                </a>
            </div>
        </div>
    </div>

    <?php if (isset($_GET['message'])): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo htmlspecialchars($_GET['message']); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>

    <?php if (isset($success)): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo $success; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>

    <?php if (isset($error)): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo $error; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>软件名称</th>
                            <th>版本</th>
                            <th>软件编码</th>
                            <th>下载次数</th>
                            <th>状态</th>
                            <th>创建时间</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($software_list as $software): ?>
                        <tr>
                            <td><?php echo $software['id']; ?></td>
                            <td>
                                <?php if ($software['icon_path']): ?>
                                <img src="<?php echo $base_url . '/' . $software['icon_path']; ?>" 
                                     alt="icon" 
                                     style="width: 24px; height: 24px; margin-right: 8px; object-fit: cover; border-radius: 4px;">
                                <?php else: ?>
                                <div class="d-inline-block text-center" 
                                     style="width: 24px; height: 24px; margin-right: 8px; background-color: #e9ecef; border-radius: 4px;">
                                    <i class="bi bi-box"></i>
                                </div>
                                <?php endif; ?>
                                <?php echo htmlspecialchars($software['name']); ?>
                            </td>
                            <td><?php echo htmlspecialchars($software['version']); ?></td>
                            <td><?php echo htmlspecialchars($software['code']); ?></td>
                            <td><?php echo $software['download_count']; ?></td>
                            <td>
                                <span class="badge bg-<?php echo $software['status'] ? 'success' : 'danger'; ?>">
                                    <?php echo $software['status'] ? '启用' : '禁用'; ?>
                                </span>
                            </td>
                            <td><?php echo $software['created_at']; ?></td>
                            <td>
                                <div class="btn-group">
                                    <a href="?page=software_edit&id=<?php echo $software['id']; ?>" 
                                       class="btn btn-sm btn-outline-primary">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <button type="button" 
                                            class="btn btn-sm btn-outline-danger" 
                                            onclick="deleteSoftware(<?php echo $software['id']; ?>)">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
function deleteSoftware(id) {
    if (confirm('确定要删除这个软件吗？删除后将无法恢复，相关文件也会被删除。')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = `
            <input type="hidden" name="delete" value="1">
            <input type="hidden" name="id" value="${id}">
        `;
        document.body.appendChild(form);
        form.submit();
    }
}
</script>


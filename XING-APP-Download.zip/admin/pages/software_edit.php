<?php
// 检查是否有权限访问
if (!defined('IN_ADMIN')) {
    exit('Access Denied');
}

// 获取网站根目录URL
$base_url = rtrim(dirname(dirname($_SERVER['PHP_SELF'])), '/') . '/..';

// 获取软件信息(如果是编辑)
$software = null;
if (isset($_GET['id'])) {
    $stmt = $db->prepare("SELECT * FROM software WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    $software = $stmt->fetch();
    if (!$software) {
        $error = "软件不存在";
    }
}

// 生成软件编码
function generateSoftwareCode() {
    return strtoupper(substr(md5(uniqid()), 0, 8));
}

// 处理表单提交
if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $version = $_POST['version'];
    $description = $_POST['description'];
    $status = isset($_POST['status']) ? 1 : 0;
    $platform = $_POST['platform'];
    $min_os_version = $_POST['min_os_version'];
    $recommended_os_version = $_POST['recommended_os_version'];
    $release_date = $_POST['release_date'];
    $update_log = $_POST['update_log'];
    
    // 如果是新增，生成软件编码；如果是编辑，使用原有编码
    $code = $software ? $software['code'] : generateSoftwareCode();

    // 处理文件上传
    $file_path = $software ? $software['file_path'] : '';
    if (isset($_FILES['file']) && $_FILES['file']['size'] > 0) {
        $upload_dir = __DIR__ . '/../../uploads/software/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        $file_ext = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));
        $file_name = uniqid() . '.' . $file_ext;
        $file_path = 'uploads/software/' . $file_name;
        
        move_uploaded_file($_FILES['file']['tmp_name'], $upload_dir . $file_name);
    }

    // 处理图标上传
    $icon_path = $software ? $software['icon_path'] : '';
    if (isset($_FILES['icon']) && $_FILES['icon']['size'] > 0) {
        $upload_dir = __DIR__ . '/../../uploads/icons/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        $icon_ext = strtolower(pathinfo($_FILES['icon']['name'], PATHINFO_EXTENSION));
        $icon_name = uniqid() . '.' . $icon_ext;
        $icon_path = 'uploads/icons/' . $icon_name;
        
        move_uploaded_file($_FILES['icon']['tmp_name'], $upload_dir . $icon_name);
    }

    // 在处理表单提交的代码块中，修改处理截图的部分
    // 首先初始化 $screenshots 数组，确保包含现有的截图
    $screenshots = $software ? json_decode($software['screenshots'], true) : [];
    if (!is_array($screenshots)) {
        $screenshots = [];
    }

    // 处理要删除的截图
    if (isset($_POST['remove_screenshots']) && is_array($_POST['remove_screenshots'])) {
        foreach ($_POST['remove_screenshots'] as $remove_path) {
            // 从数组中移除要删除的截图
            $screenshots = array_filter($screenshots, function($screenshot) use ($remove_path) {
                return $screenshot !== $remove_path;
            });
            
            // 删除实际文件
            $full_path = __DIR__ . '/../../' . $remove_path;
            if (file_exists($full_path)) {
                unlink($full_path);
            }
        }
    }

    // 处理新上传的截图
    if (isset($_FILES['screenshots'])) {
        $upload_dir = __DIR__ . '/../../uploads/screenshots/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        foreach ($_FILES['screenshots']['tmp_name'] as $key => $tmp_name) {
            if ($_FILES['screenshots']['size'][$key] > 0) {
                $screenshot_ext = strtolower(pathinfo($_FILES['screenshots']['name'][$key], PATHINFO_EXTENSION));
                $screenshot_name = uniqid() . '.' . $screenshot_ext;
                $screenshot_path = 'uploads/screenshots/' . $screenshot_name;
                
                move_uploaded_file($tmp_name, $upload_dir . $screenshot_name);
                $screenshots[] = $screenshot_path;  // 添加新截图到现有数组中
            }
        }
    }

    try {
        if ($software) {
            // 更新软件
            $stmt = $db->prepare("
                UPDATE software SET 
                name = ?, version = ?, description = ?, file_path = ?, 
                status = ?, platform = ?, min_os_version = ?, 
                recommended_os_version = ?, release_date = ?, 
                update_log = ?, icon_path = ?, screenshots = ?,
                updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            ");
            $stmt->execute([
                $name, $version, $description, $file_path, 
                $status, $platform, $min_os_version,
                $recommended_os_version, $release_date, 
                $update_log, $icon_path, json_encode($screenshots),
                $software['id']
            ]);
            $success = "软件更新成功";
        } else {
            // 添加新软件
            $stmt = $db->prepare("
                INSERT INTO software (
                    name, version, description, file_path, status,
                    platform, min_os_version, recommended_os_version,
                    release_date, update_log, icon_path, screenshots, code
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $name, $version, $description, $file_path, $status,
                $platform, $min_os_version, $recommended_os_version,
                $release_date, $update_log, $icon_path, json_encode($screenshots), $code
            ]);
            $success = "软件添加成功";
        }
    } catch (PDOException $e) {
        $error = "操作失败: " . $e->getMessage();
    }
}

// 如果是新增，生成软件编码
$code = $software ? $software['code'] : generateSoftwareCode();
?>

<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <h4 class="mb-0"><?php echo $software ? '编辑软件' : '添加软件'; ?></h4>
                <a href="?page=software" class="btn btn-secondary">
                    <i class="bi bi-arrow-left"></i> 返回
                </a>
            </div>
        </div>
    </div>

    <?php if (isset($error)): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo $error; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <form method="POST" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">软件名称</label>
                            <input type="text" class="form-control" name="name" required
                                   value="<?php echo $software ? htmlspecialchars($software['name']) : ''; ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">版本号</label>
                            <input type="text" class="form-control" name="version" required
                                   value="<?php echo $software ? htmlspecialchars($software['version']) : ''; ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">软件编码</label>
                            <input type="text" class="form-control" value="<?php echo htmlspecialchars($code); ?>" readonly
                                   style="background-color: #e9ecef;">
                            <div class="form-text">软件编码自动生成，不可修改</div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">支持平台</label>
                            <input type="text" class="form-control" name="platform"
                                   value="<?php echo $software ? htmlspecialchars($software['platform']) : ''; ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">最低系统版本</label>
                            <input type="text" class="form-control" name="min_os_version"
                                   value="<?php echo $software ? htmlspecialchars($software['min_os_version']) : ''; ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">推荐系统版本</label>
                            <input type="text" class="form-control" name="recommended_os_version"
                                   value="<?php echo $software ? htmlspecialchars($software['recommended_os_version']) : ''; ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">发布日期</label>
                            <input type="date" class="form-control" name="release_date"
                                   value="<?php echo $software ? $software['release_date'] : date('Y-m-d'); ?>">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">软件描述</label>
                            <textarea class="form-control" name="description" rows="3"><?php 
                                echo $software ? htmlspecialchars($software['description']) : ''; 
                            ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">更新日志</label>
                            <textarea class="form-control" name="update_log" rows="3"><?php 
                                echo $software ? htmlspecialchars($software['update_log']) : ''; 
                            ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">软件文件</label>
                            <input type="file" class="form-control" name="file" 
                                   <?php echo !$software ? 'required' : ''; ?>>
                            <?php if ($software && $software['file_path']): ?>
                            <small class="text-muted">当前文件: <?php echo $software['file_path']; ?></small>
                            <?php endif; ?>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">软件图标</label>
                            <input type="file" class="form-control" name="icon" accept="image/*">
                            <?php if ($software && $software['icon_path']): ?>
                            <small class="text-muted">当前图标: <?php echo $software['icon_path']; ?></small>
                            <?php endif; ?>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">软件截图</label>
                            <input type="file" class="form-control" name="screenshots[]" multiple accept="image/*">
                            <?php if ($software && $software['screenshots']): 
                                $current_screenshots = json_decode($software['screenshots'], true);
                                if ($current_screenshots): ?>
                                <div class="mt-2 screenshots-container">
                                    <small class="text-muted">当前截图:</small>
                                    <div class="d-flex flex-wrap gap-2 mt-1">
                                        <?php foreach ($current_screenshots as $screenshot): ?>
                                        <div class="position-relative">
                                            <img src="<?php echo  '/' . $screenshot; ?>" 
                                                 alt="截图" 
                                                 style="width: 100px; height: 100px; object-fit: cover; border-radius: 4px;">
                                            <button type="button" 
                                                    class="btn btn-sm btn-danger position-absolute top-0 end-0 m-1"
                                                    onclick="removeScreenshot(this, '<?php echo $screenshot; ?>')"
                                                    style="padding: 0.1rem 0.3rem;">
                                                <i class="bi bi-x"></i>
                                            </button>
                                        </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                                <?php endif;
                            endif; ?>
                        </div>
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" name="status" id="status"
                                   <?php echo (!$software || $software['status']) ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="status">启用</label>
                        </div>
                    </div>
                </div>
                <div class="text-end">
                    <button type="submit" name="submit" class="btn btn-primary">
                        <i class="bi bi-save"></i> 保存
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if (isset($success)): ?>
<script>
    // 使用JavaScript进行重定向
    alert("<?php echo $success; ?>");
    window.location.href = "?page=software";
</script>
<?php endif; ?>

<script>
function removeScreenshot(button, path) {
    if (confirm('确定要删除这张截图吗？')) {
        // 移除显示的图片
        button.parentElement.remove();
        
        // 添加隐藏字段记录要删除的截图
        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'remove_screenshots[]';
        input.value = path;
        document.querySelector('form').appendChild(input);
        
        // 可选：添加视觉反馈
        const feedback = document.createElement('div');
        feedback.className = 'alert alert-warning mt-2';
        feedback.textContent = '截图将在保存后被删除';
        feedback.style.fontSize = '0.8rem';
        document.querySelector('.screenshots-container').appendChild(feedback);
    }
}

// 添加文件预览功能
document.querySelector('input[name="screenshots[]"]').addEventListener('change', function(e) {
    const files = e.target.files;
    const container = document.querySelector('.screenshots-container');
    
    // 如果还没有container，创建一个
    if (!container) {
        const newContainer = document.createElement('div');
        newContainer.className = 'mt-2 screenshots-container';
        const small = document.createElement('small');
        small.className = 'text-muted';
        small.textContent = '当前截图:';
        newContainer.appendChild(small);
        
        const previewDiv = document.createElement('div');
        previewDiv.className = 'd-flex flex-wrap gap-2 mt-1';
        newContainer.appendChild(previewDiv);
        
        this.parentElement.appendChild(newContainer);
    }
    
    const previewContainer = (container || document.querySelector('.screenshots-container'))
        .querySelector('.d-flex');
    
    // 为每个选择的文件创建预览
    for (let file of files) {
        const reader = new FileReader();
        reader.onload = function(e) {
            const div = document.createElement('div');
            div.className = 'position-relative';
            div.innerHTML = `
                <img src="${e.target.result}" 
                     alt="预览" 
                     style="width: 100px; height: 100px; object-fit: cover; border-radius: 4px;">
                <button type="button" 
                        class="btn btn-sm btn-danger position-absolute top-0 end-0 m-1"
                        style="padding: 0.1rem 0.3rem;">
                    <i class="bi bi-x"></i>
                </button>
            `;
            
            // 添加删除预览的功能
            div.querySelector('button').addEventListener('click', function() {
                if (confirm('确定要移除这张截图吗？')) {
                    div.remove();
                }
            });
            
            previewContainer.appendChild(div);
        };
        reader.readAsDataURL(file);
    }
});
</script> 
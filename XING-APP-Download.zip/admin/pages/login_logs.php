<?php
// 检查是否有权限访问
if (!defined('IN_ADMIN')) {
    exit('Access Denied');
}

// 分页设置
$page = isset($_GET['p']) ? (int)$_GET['p'] : 1;
$per_page = 20;
$offset = ($page - 1) * $per_page;

// 获取总记录数
$total = $db->query("SELECT COUNT(*) FROM admin_login_logs")->fetchColumn();
$total_pages = ceil($total / $per_page);

// 获取日志列表 - 修改查询以处理可能为空的关联
$sql = "
    SELECT l.*, 
           COALESCE(u.username, l.username) as display_username 
    FROM admin_login_logs l 
    LEFT JOIN admin_users u ON l.admin_id = u.id 
    ORDER BY l.login_time DESC 
    LIMIT :limit OFFSET :offset
";

$stmt = $db->prepare($sql);
$stmt->bindValue(':limit', $per_page, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$logs = $stmt->fetchAll();
?>

<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-12">
            <h4>登录日志</h4>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>用户名</th>
                            <th>IP地址</th>
                            <th>状态</th>
                            <th>登录时间</th>
                            <th>浏览器信息</th>
                            <th>备注</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($logs as $log): ?>
                        <tr>
                            <td><?php echo $log['id']; ?></td>
                            <td><?php echo htmlspecialchars($log['display_username']); ?></td>
                            <td><?php echo htmlspecialchars($log['ip']); ?></td>
                            <td>
                                <span class="badge bg-<?php echo $log['status'] ? 'success' : 'danger'; ?>">
                                    <?php echo $log['status'] ? '成功' : '失败'; ?>
                                </span>
                            </td>
                            <td><?php echo $log['login_time']; ?></td>
                            <td>
                                <span class="text-truncate d-inline-block" style="max-width: 200px;" 
                                      title="<?php echo htmlspecialchars($log['user_agent']); ?>">
                                    <?php echo htmlspecialchars($log['user_agent']); ?>
                                </span>
                            </td>
                            <td><?php echo htmlspecialchars($log['remark'] ?? ''); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <?php if ($total_pages > 1): ?>
            <nav class="mt-4">
                <ul class="pagination justify-content-center">
                    <?php if ($page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=login_logs&p=1">首页</a>
                    </li>
                    <li class="page-item">
                        <a class="page-link" href="?page=login_logs&p=<?php echo ($page - 1); ?>">上一页</a>
                    </li>
                    <?php endif; ?>

                    <?php
                    // 计算显示的页码范围
                    $start_page = max(1, $page - 2);
                    $end_page = min($total_pages, $page + 2);
                    
                    for ($i = $start_page; $i <= $end_page; $i++):
                    ?>
                    <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                        <a class="page-link" href="?page=login_logs&p=<?php echo $i; ?>">
                            <?php echo $i; ?>
                        </a>
                    </li>
                    <?php endfor; ?>

                    <?php if ($page < $total_pages): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=login_logs&p=<?php echo ($page + 1); ?>">下一页</a>
                    </li>
                    <li class="page-item">
                        <a class="page-link" href="?page=login_logs&p=<?php echo $total_pages; ?>">末页</a>
                    </li>
                    <?php endif; ?>
                </ul>
            </nav>
            <?php endif; ?>
        </div>
    </div>
</div>

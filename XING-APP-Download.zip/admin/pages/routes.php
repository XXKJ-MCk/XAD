<?php
// 检查是否有权限访问
if (!defined('IN_ADMIN')) {
    exit('Access Denied');
}

// 处理线路删除
if (isset($_POST['delete']) && isset($_POST['id'])) {
    try {
        $stmt = $db->prepare("DELETE FROM routes WHERE id = ?");
        $stmt->execute([$_POST['id']]);
        $success = "删除成功";
    } catch (PDOException $e) {
        $error = "删除失败: " . $e->getMessage();
    }
}

// 处理添加/编辑线路
if (isset($_POST['submit'])) {
    $software_id = $_POST['software_id'];
    $name = trim($_POST['name']);
    $url = trim($_POST['url']);
    $status = isset($_POST['status']) ? 1 : 0;
    $sort_order = (int)$_POST['sort_order'];
    
    try {
        if (isset($_POST['id']) && !empty($_POST['id'])) {
            // 更新线路
            $stmt = $db->prepare("
                UPDATE routes 
                SET software_id = ?, name = ?, url = ?, status = ?, sort_order = ?, 
                    updated_at = CURRENT_TIMESTAMP 
                WHERE id = ?
            ");
            $stmt->execute([$software_id, $name, $url, $status, $sort_order, $_POST['id']]);
            $success = "线路更新成功";
        } else {
            // 添加新线路
            $stmt = $db->prepare("
                INSERT INTO routes 
                (software_id, name, url, status, sort_order, created_at) 
                VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            ");
            $stmt->execute([$software_id, $name, $url, $status, $sort_order]);
            $success = "线路添加成功";
        }
    } catch (PDOException $e) {
        $error = "操作失败: " . $e->getMessage();
    }
}

// 获取软件列表(用于选择)
$software_list = $db->query("
    SELECT id, name, code 
    FROM software 
    WHERE status = 1 
    ORDER BY name
")->fetchAll();

// 获取线路列表（包括软件编码）
$stmt = $db->query("
    SELECT r.*, 
           s.name as software_name,
           s.code as software_code
    FROM routes r 
    LEFT JOIN software s ON r.software_id = s.id 
    ORDER BY r.sort_order ASC, r.id DESC
");
$routes = $stmt->fetchAll();
?>

<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <h4 class="mb-0">线路管理</h4>
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#routeModal">
                    <i class="bi bi-plus-lg"></i> 添加线路
                </button>
            </div>
        </div>
    </div>

    <?php if (isset($success)): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo $success; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>

    <?php if (isset($error)): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo $error; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>所属软件</th>
                            <th>软件编码</th>
                            <th>线路名称</th>
                            <th>线路地址</th>
                            <th>排序</th>
                            <th>状态</th>
                            <th>创建时间</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($routes as $route): ?>
                        <tr>
                            <td><?php echo $route['id']; ?></td>
                            <td><?php echo htmlspecialchars($route['software_name']); ?></td>
                            <td><?php echo htmlspecialchars($route['software_code']); ?></td>
                            <td><?php echo htmlspecialchars($route['name']); ?></td>
                            <td>
                                <span class="text-truncate d-inline-block" style="max-width: 200px;" 
                                      title="<?php echo htmlspecialchars($route['url']); ?>">
                                    <?php echo htmlspecialchars($route['url']); ?>
                                </span>
                            </td>
                            <td><?php echo $route['sort_order']; ?></td>
                            <td>
                                <span class="badge bg-<?php echo $route['status'] ? 'success' : 'danger'; ?>">
                                    <?php echo $route['status'] ? '启用' : '禁用'; ?>
                                </span>
                            </td>
                            <td><?php echo $route['created_at']; ?></td>
                            <td>
                                <div class="btn-group">
                                    <button type="button" 
                                            class="btn btn-sm btn-outline-primary"
                                            onclick='editRoute(<?php 
                                                // 准备需要的数据
                                                $routeData = [
                                                    'id' => $route['id'],
                                                    'software_id' => $route['software_id'],
                                                    'name' => $route['name'],
                                                    'url' => $route['url'],
                                                    'sort_order' => $route['sort_order'],
                                                    'status' => $route['status']
                                                ];
                                                echo json_encode($routeData, JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE);
                                            ?>)'>
                                        <i class="bi bi-pencil"></i>
                                    </button>
                                    <button type="button" 
                                            class="btn btn-sm btn-outline-danger"
                                            onclick="deleteRoute(<?php echo $route['id']; ?>)">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- 线路添加/编辑模态框 -->
<div class="modal fade" id="routeModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" id="routeForm" onsubmit="return validateForm()">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTitle">添加线路</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="id" id="routeId">
                    <div class="mb-3">
                        <label class="form-label">所属软件</label>
                        <select class="form-select" name="software_id" id="softwareId" required>
                            <option value="">请选择软件</option>
                            <?php foreach ($software_list as $software): ?>
                            <option value="<?php echo $software['id']; ?>">
                                <?php echo htmlspecialchars($software['name']); ?> 
                                (<?php echo htmlspecialchars($software['code']); ?>)
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">线路名称</label>
                        <input type="text" class="form-control" name="name" id="routeName" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">线路地址</label>
                        <input type="url" class="form-control" name="url" id="routeUrl" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">排序</label>
                        <input type="number" class="form-control" name="sort_order" id="sortOrder" value="0" min="0">
                    </div>
                    <div class="mb-3 form-check">
                        <input type="checkbox" class="form-check-input" name="status" id="routeStatus" checked>
                        <label class="form-check-label" for="routeStatus">启用</label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                    <button type="submit" name="submit" class="btn btn-primary">保存</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
let routeModal;

// DOM加载完成后初始化模态框
document.addEventListener('DOMContentLoaded', function() {
    routeModal = new bootstrap.Modal(document.getElementById('routeModal'));
});

function editRoute(route) {
    try {
        console.log('编辑路由数据:', route); // 调试用
        
        // 设置表单值
        document.getElementById('modalTitle').textContent = '编辑线路';
        document.getElementById('routeId').value = route.id || '';
        document.getElementById('softwareId').value = route.software_id || '';
        document.getElementById('routeName').value = route.name || '';
        document.getElementById('routeUrl').value = route.url || '';
        document.getElementById('sortOrder').value = route.sort_order || 0;
        document.getElementById('routeStatus').checked = route.status == 1;
        
        // 显示模态框
        if (routeModal) {
            routeModal.show();
        } else {
            console.error('模态框未初始化');
        }
    } catch (error) {
        console.error('编辑线路时出错:', error);
        console.log('路由数据:', route);
        alert('编辑线路时出错，请查看控制台了解详情');
    }
}

function deleteRoute(id) {
    if (confirm('确定要删除这个线路吗？')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = `
            <input type="hidden" name="delete" value="1">
            <input type="hidden" name="id" value="${id}">
        `;
        document.body.appendChild(form);
        form.submit();
    }
}

// 重置表单
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('routeModal').addEventListener('hidden.bs.modal', function () {
        document.getElementById('modalTitle').textContent = '添加线路';
        document.getElementById('routeForm').reset();
        document.getElementById('routeId').value = '';
    });
});

// 添加表单验证
function validateForm() {
    const name = document.getElementById('routeName').value.trim();
    const url = document.getElementById('routeUrl').value.trim();
    const softwareId = document.getElementById('softwareId').value;
    
    if (!softwareId) {
        alert('请选择所属软件');
        return false;
    }
    if (!name) {
        alert('请输入线路名称');
        return false;
    }
    if (!url) {
        alert('请输入线路地址');
        return false;
    }
    return true;
}
</script>

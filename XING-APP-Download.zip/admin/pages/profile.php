<?php
// 检查是否有权限访问
if (!defined('IN_ADMIN')) {
    exit('Access Denied');
}

$user_id = $_SESSION['admin_id'];

// 处理密码修改
if (isset($_POST['change_password'])) {
    $old_password = $_POST['old_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    // 验证旧密码
    $stmt = $db->prepare("SELECT password FROM admin_users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    
    if (!password_verify($old_password, $user['password'])) {
        $error = "旧密码不正确";
    } elseif ($new_password !== $confirm_password) {
        $error = "两次输入的新密码不一致";
    } elseif (strlen($new_password) < 6) {
        $error = "新密码长度不能小于6位";
    } else {
        // 更新密码
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $stmt = $db->prepare("UPDATE admin_users SET password = ? WHERE id = ?");
        $stmt->execute([$hashed_password, $user_id]);
        $success = "密码修改成功";
    }
}

// 处理用户名修改
if (isset($_POST['change_username'])) {
    $new_username = trim($_POST['new_username']);
    
    // 验证用户名
    if (empty($new_username)) {
        $error = "用户名不能为空";
    } elseif (strlen($new_username) < 3) {
        $error = "用户名长度不能小于3位";
    } else {
        // 检查用户名是否已存在
        $stmt = $db->prepare("SELECT COUNT(*) FROM admin_users WHERE username = ? AND id != ?");
        $stmt->execute([$new_username, $user_id]);
        if ($stmt->fetchColumn() > 0) {
            $error = "该用户名已被使用";
        } else {
            // 更新用户名
            $stmt = $db->prepare("UPDATE admin_users SET username = ? WHERE id = ?");
            $stmt->execute([$new_username, $user_id]);
            $_SESSION['admin_username'] = $new_username; // 更新会话中的用户名
            $success = "用户名修改成功";
        }
    }
}

// 获取用户信息
$stmt = $db->prepare("SELECT * FROM admin_users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();
?>

<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-12">
            <h4>个人设置</h4>
        </div>
    </div>

    <?php if (isset($error)): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo $error; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <?php if (isset($success)): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo $success; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title mb-4">基本信息</h5>
                    <form method="POST" class="mb-4">
                        <div class="mb-3">
                            <label class="form-label">当前用户名</label>
                            <input type="text" class="form-control" value="<?php echo htmlspecialchars($user['username']); ?>" readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">新用户名</label>
                            <input type="text" class="form-control" name="new_username" minlength="3" required>
                            <div class="form-text">用户名长度至少3位</div>
                        </div>
                        <button type="submit" name="change_username" class="btn btn-primary">
                            修改用户名
                        </button>
                    </form>
                    <div class="mb-3">
                        <label class="form-label">最后登录时间</label>
                        <input type="text" class="form-control" value="<?php echo $user['last_login']; ?>" readonly>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title mb-4">修改密码</h5>
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">旧密码</label>
                            <input type="password" class="form-control" name="old_password" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">新密码</label>
                            <input type="password" class="form-control" name="new_password" minlength="6" required>
                            <div class="form-text">密码长度至少6位</div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">确认新密码</label>
                            <input type="password" class="form-control" name="confirm_password" minlength="6" required>
                        </div>
                        <button type="submit" name="change_password" class="btn btn-primary">
                            修改密码
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// 检查是否有权限访问
if (!defined('IN_ADMIN')) {
    exit('Access Denied');
}

// 获取配置信息
$config = require(__DIR__ . '/../../config/config.php');
$system_config = $config['system'];

// 检查更新
function checkUpdate() {
    global $system_config; // 使用 global 关键字引入全局变量
    
    $current_version = $system_config['version'];
    $current_build = $system_config['build'];
    
    // 这里替换为实际的更新检查接口
    $update_api = "http://www.xxkj.pro/api/update.php";
    $params = [
        'version' => $current_version,
        'build' => $current_build
    ];
    
    try {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $update_api . '?' . http_build_query($params));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        $response = curl_exec($ch);
        
        if (curl_errno($ch)) {
            throw new Exception(curl_error($ch));
        }
        
        curl_close($ch);
        
        if ($response) {
            $data = json_decode($response, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw new Exception('JSON解析错误：' . json_last_error_msg());
            }
            
            // 检查返回的数据格式是否正确
            if (!isset($data['version']) || !isset($data['build'])) {
                throw new Exception('接口返回数据格式不正确');
            }
            
            // 比较版本号
            $hasUpdate = version_compare($data['version'], $current_version, '>') || 
                        ($data['version'] === $current_version && $data['build'] > $current_build);
            
            return [
                'hasUpdate' => $hasUpdate,
                'version' => $data['version'],
                'build' => $data['build'],
                'releaseDate' => $data['releaseDate'] ?? '',
                'description' => $data['description'] ?? '',
                'downloadUrl' => $data['downloadUrl'] ?? '',
                'currentVersion' => $current_version,
                'currentBuild' => $current_build
            ];
        }
        
        throw new Exception('接口未返回数据');
    } catch (Exception $e) {
        return ['error' => $e->getMessage()];
    }
}

// 如果是AJAX请求检查更新
if (isset($_GET['check_update'])) {
    ob_clean(); // 清除之前的输出缓冲
    header('Content-Type: application/json');
    echo json_encode(checkUpdate());
    exit;
}
?>

<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-12">
            <h4>版本信息</h4>
        </div>
    </div>

    <!-- 版本对比卡片 -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <h5 class="card-title mb-0">版本检查</h5>
                        <button type="button" class="btn btn-primary" onclick="checkUpdate()">
                            <i class="bi bi-arrow-clockwise"></i> 检查更新
                        </button>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="border rounded p-3 h-100">
                                <h6 class="mb-3">当前版本</h6>
                                <table class="table table-sm">
                                    <tr>
                                        <th style="width: 120px;">版本号</th>
                                        <td><?php echo htmlspecialchars($system_config['version']); ?></td>
                                    </tr>
                                    <tr>
                                        <th>构建编号</th>
                                        <td><?php echo htmlspecialchars($system_config['build']); ?></td>
                                    </tr>
                                    <tr>
                                        <th>发布日期</th>
                                        <td><?php echo htmlspecialchars($system_config['release_date']); ?></td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="border rounded p-3 h-100" id="latestVersion">
                                <h6 class="mb-3">最新版本</h6>
                                <div class="text-center py-4 text-muted">
                                    <i class="bi bi-arrow-clockwise"></i> 点击检查更新按钮获取最新版本信息
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- 更新提示 -->
                    <div id="updateAlert" class="alert alert-info alert-dismissible fade d-none mt-3 mb-0" role="alert">
                        <div id="updateMessage"></div>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title mb-4">系统信息</h5>
                    <table class="table">
                        <tbody>
                            <tr>
                                <th style="width: 200px;">系统名称</th>
                                <td><?php echo htmlspecialchars($system_config['name']); ?></td>
                            </tr>
                            <tr>
                                <th>PHP 版本</th>
                                <td><?php echo PHP_VERSION; ?></td>
                            </tr>
                            <tr>
                                <th>MySQL 版本</th>
                                <td><?php echo $db->query('SELECT VERSION()')->fetchColumn(); ?></td>
                            </tr>
                            <tr>
                                <th>服务器操作系统</th>
                                <td><?php echo PHP_OS; ?></td>
                            </tr>
                            <tr>
                                <th>服务器软件</th>
                                <td><?php echo $_SERVER['SERVER_SOFTWARE']; ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title mb-4">开发信息</h5>
                    <table class="table">
                        <tbody>
                            <tr>
                                <th style="width: 200px;">开发者</th>
                                <td>慕尘空</td>
                            </tr>
                            <tr>
                                <th>官方网站</th>
                                <td><a href="http://www.xxkj.pro/" target="_blank">http://www.xxkj.pro/</a></td>
                            </tr>
                            <tr>
                                <th>技术支持</th>
                                <td><a href="mailto:1265009463@qq.com">1265009463@qq.com</a></td>
                            </tr>
                            <tr>
                                <th>版权信息</th>
                                <td>© <?php echo date('Y'); ?> 星筱科技 All rights reserved.</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
async function checkUpdate() {
    const button = document.querySelector('.btn-primary');
    const originalHtml = button.innerHTML;
    button.disabled = true;
    button.innerHTML = '<i class="bi bi-arrow-clockwise"></i> 检查中...';
    
    try {
        const response = await fetch('?page=version&check_update=1');
        const data = await response.json();
        
        const alert = document.getElementById('updateAlert');
        const message = document.getElementById('updateMessage');
        const latestVersion = document.getElementById('latestVersion');
        
        // 更新最新版本信息
        if (data.error) {
            latestVersion.innerHTML = `
                <h6 class="mb-3">最新版本</h6>
                <div class="text-center py-4 text-danger">
                    <i class="bi bi-exclamation-circle"></i> 获取失败: ${data.error}
                </div>
            `;
            alert.classList.remove('alert-info', 'alert-success');
            alert.classList.add('alert-danger');
            message.innerHTML = `检查更新失败: ${data.error}`;
        } else if (data.hasUpdate) {
            latestVersion.innerHTML = `
                <h6 class="mb-3">最新版本</h6>
                <table class="table table-sm">
                    <tr>
                        <th style="width: 120px;">版本号</th>
                        <td>${data.version}</td>
                    </tr>
                    <tr>
                        <th>构建编号</th>
                        <td>${data.build}</td>
                    </tr>
                    <tr>
                        <th>发布日期</th>
                        <td>${data.releaseDate}</td>
                    </tr>
                </table>
                <div class="mt-2">
                    <a href="${data.downloadUrl}" class="btn btn-sm btn-success">
                        <i class="bi bi-download"></i> 下载更新
                    </a>
                </div>
            `;
            alert.classList.remove('alert-info', 'alert-danger');
            alert.classList.add('alert-success');
            message.innerHTML = `
                发现新版本!<br>
                更新内容: ${data.description}
            `;
        } else {
            latestVersion.innerHTML = `
                <h6 class="mb-3">最新版本</h6>
                <div class="text-center py-4 text-success">
                    <i class="bi bi-check-circle"></i> 当前已是最新版本
                </div>
            `;
            alert.classList.remove('alert-success', 'alert-danger');
            alert.classList.add('alert-info');
            message.innerHTML = '当前已是最新版本';
        }
        
        alert.classList.remove('d-none');
        alert.classList.add('show');
    } catch (error) {
        console.error('检查更新失败:', error);
        document.getElementById('latestVersion').innerHTML = `
            <h6 class="mb-3">最新版本</h6>
            <div class="text-center py-4 text-danger">
                <i class="bi bi-exclamation-circle"></i> 检查更新失败
            </div>
        `;
    } finally {
        button.disabled = false;
        button.innerHTML = originalHtml;
    }
}
</script>

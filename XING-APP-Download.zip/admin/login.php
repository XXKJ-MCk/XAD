<?php
session_start();
session_regenerate_id(true);
require_once(__DIR__ . '/../config/database.php');
require_once(__DIR__ . '/../config/common.php');

// 常量定义
define('LOGIN_TIMEOUT', 1800); // 30分钟

// 生成 CSRF 令牌
function generateCSRFToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        $_SESSION['csrf_token_time'] = time();
    } else if (time() - $_SESSION['csrf_token_time'] > 3600) {
        // 令牌超时，重新生成
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        $_SESSION['csrf_token_time'] = time();
    }
    return $_SESSION['csrf_token'];
}

// 添加会话过期检查
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > LOGIN_TIMEOUT)) {
    session_unset();
    session_destroy();
    header('Location: login.php');
    exit;
}
$_SESSION['last_activity'] = time();

// 处理登录请求
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // 验证 CSRF 令牌
        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== generateCSRFToken()) {
            throw new Exception('无效的请求，请刷新页面重试');
        }

        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        $captcha = trim($_POST['captcha'] ?? '');

        // 添加基本输入验证
        if (empty($username) || empty($password)) {
            throw new Exception('用户名和密码不能为空');
        }
        
        // 检查登录尝试次数
        $stmt = $db->prepare("SELECT COUNT(*) FROM login_attempts WHERE ip = ? AND attempt_time > DATE_SUB(NOW(), INTERVAL 1 HOUR)");
        $stmt->execute([$_SERVER['REMOTE_ADDR']]);
        $attempts = $stmt->fetchColumn();
        
        if ($attempts >= 5) {
            throw new Exception('登录尝试次数过多，请1小时后再试');
        }

        // 验证验证码
        if (!isset($_SESSION['captcha']) || strtoupper($captcha) !== strtoupper($_SESSION['captcha'])) {
            // 记录失败尝试
            $stmt = $db->prepare("INSERT INTO login_attempts (ip, attempt_time) VALUES (?, NOW())");
            $stmt->execute([$_SERVER['REMOTE_ADDR']]);
            throw new Exception('验证码错误');
        }

        // 验证用户名和密码
        $stmt = $db->prepare("SELECT id, password, status FROM admin_users WHERE username = ?");
        $stmt->bindParam(1, $username, PDO::PARAM_STR); // 明确指定参数类型
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user) {
            throw new Exception('用户名或密码错误');
        }

        if ($user['status'] != 1) {
            throw new Exception('该账号已被禁用，请联系管理员');
        }

        // 使用更安全的密码哈希选项
        $hash_options = [
            'memory_cost' => 1024 * 64,
            'time_cost' => 4,
            'threads' => 3
        ];

        $password_hash = password_hash($password, PASSWORD_ARGON2ID, $hash_options);

        if (!password_verify($password_hash, $user['password'])) {
            // 记录失败尝试
            $stmt = $db->prepare("INSERT INTO login_attempts (ip, attempt_time) VALUES (?, NOW())");
            $stmt->execute([$_SERVER['REMOTE_ADDR']]);
            throw new Exception('用户名或密码错误');
        }

        // 登录成功后清除该IP的登录尝试记录
        $stmt = $db->prepare("DELETE FROM login_attempts WHERE ip = ?");
        $stmt->execute([$_SERVER['REMOTE_ADDR']]);

        // 登录成功
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_username'] = $username;
        $_SESSION['admin_id'] = $user['id']; // 保存管理员ID到会话
        $_SESSION['admin_ip'] = $_SERVER['REMOTE_ADDR'];
        $_SESSION['last_activity'] = time();

        // 记录登录日志
        $stmt = $db->prepare("INSERT INTO admin_login_logs (admin_id, username, ip, user_agent, status, remark) VALUES (?, ?, ?, ?, 1, '登录成功')");
        $stmt->execute([
            $user['id'], // 使用获取到的管理员ID
            $username,
            $_SERVER['REMOTE_ADDR'],
            $_SERVER['HTTP_USER_AGENT']
        ]);

        // 更新最后登录时间
        $stmt = $db->prepare("UPDATE admin_users SET last_login = NOW() WHERE id = ?");
        $stmt->execute([$user['id']]);

        // 如果用户选择了"记住我"
        if (isset($_POST['remember']) && $_POST['remember'] == '1') {
            // 生成唯一的令牌
            $remember_token = bin2hex(random_bytes(32));
            
            // 更新数据库中的remember_token
            $stmt = $db->prepare("UPDATE admin_users SET remember_token = ?, token_expires = DATE_ADD(NOW(), INTERVAL 30 DAY) WHERE id = ?");
            $stmt->execute([$remember_token, $user['id']]);
            
            // 设置cookie，30天过期
            setcookie('remember_token', $remember_token, time() + (86400 * 30), '/', '', true, true);
            setcookie('admin_id', $user['id'], time() + (86400 * 30), '/', '', true, true);
        }

        // 清除验证码session
        unset($_SESSION['captcha']);

        header('Location: index.php');
        exit;
    } catch (Exception $e) {
        $error = $e->getMessage();
        // 记录登录失败日志
        $stmt = $db->prepare("INSERT INTO admin_login_logs (admin_id, username, ip, user_agent, status, remark) VALUES (0, ?, ?, ?, 0, ?)");
        $stmt->execute([
            $username,
            $_SERVER['REMOTE_ADDR'],
            $_SERVER['HTTP_USER_AGENT'],
            $error
        ]);
    } catch (PDOException $e) {
        error_log("Login error: " . $e->getMessage());
        $error = '系统错误，请稍后重试';
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>管理员登录</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/animate.css@4.1.1/animate.min.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-box {
            background: rgba(255, 255, 255, 0.95);
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 420px;
            backdrop-filter: blur(10px);
        }
        .login-title {
            color: #2c3e50;
            font-weight: 600;
            margin-bottom: 30px;
        }
        .form-control {
            border-radius: 8px;
            padding: 12px;
            border: 2px solid #e9ecef;
            transition: all 0.3s;
        }
        .form-control:focus {
            border-color: #764ba2;
            box-shadow: 0 0 0 0.2rem rgba(118, 75, 162, 0.25);
        }
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            padding: 12px;
            font-weight: 500;
            border-radius: 8px;
            transition: all 0.3s;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(118, 75, 162, 0.4);
        }
        .input-group {
            position: relative;
        }
        .input-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #6c757d;
            z-index: 10;
        }
        .input-with-icon {
            padding-left: 40px;
        }
        .text-muted small {
            font-size: 12px;
            opacity: 0.8;
        }
        .captcha-img {
            flex-shrink: 0;
            width: 120px;
        }
        .captcha-img img {
            border-radius: 8px;
            border: 2px solid #e9ecef;
        }
    </style>
</head>
<body>
    <div class="login-box animate__animated animate__fadeIn">
        <h3 class="text-center login-title">管理员登录</h3>
        <?php if (isset($error)): ?>
            <div class="alert alert-danger animate__animated animate__shakeX"><?php echo safe_html($error); ?></div>
        <?php endif; ?>
        <form method="post" action="">
            <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
            <div class="mb-4">
                <div class="input-group">
                    <i class='bx bx-user input-icon'></i>
                    <input type="text" class="form-control input-with-icon" id="username" name="username" placeholder="请输入用户名" required>
                </div>
            </div>
            <div class="mb-4">
                <div class="input-group">
                    <i class='bx bx-lock-alt input-icon'></i>
                    <input type="password" class="form-control input-with-icon" id="password" name="password" placeholder="请输入密码" required>
                </div>
            </div>
            <div class="mb-4">
                <div class="d-flex gap-2 align-items-center">
                    <div class="input-group flex-grow-1">
                        <i class='bx bx-shield input-icon'></i>
                        <input type="text" class="form-control input-with-icon" id="captcha" name="captcha" placeholder="请输入验证码" required>
                    </div>
                    <div class="captcha-img">
                        <img src="captcha.php" onclick="this.src='captcha.php?t='+Math.random()" style="cursor:pointer; height: 44px;" title="点击刷新验证码">
                    </div>
                </div>
            </div>
            <div class="mb-3 form-check">
                <input type="checkbox" class="form-check-input" id="remember" name="remember" value="1">
                <label class="form-check-label" for="remember">记住我（30天）</label>
            </div>
            <button type="submit" class="btn btn-primary w-100">登 录</button>
        </form>
        <div class="text-center mt-3 text-muted">
            <small>Copyright © <?php echo date('Y'); ?> 星筱科技 All Rights Reserved.</small>
            
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 
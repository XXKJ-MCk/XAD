<?php
session_start();

// 清除remember token
if (isset($_COOKIE['remember_token']) && isset($_COOKIE['admin_id'])) {
    require_once(__DIR__ . '/../config/database.php');
    
    // 清除数据库中的token
    $stmt = $db->prepare("UPDATE admin_users SET remember_token = NULL, token_expires = NULL WHERE id = ?");
    $stmt->execute([$_COOKIE['admin_id']]);
    
    // 删除cookie
    setcookie('remember_token', '', time() - 3600, '/');
    setcookie('admin_id', '', time() - 3600, '/');
}

session_destroy();
header("Location: login.php");
exit;
?> 
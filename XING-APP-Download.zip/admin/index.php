<?php
ob_start();
// 开发环境下显示所有错误
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
define('IN_ADMIN', true);

// 包含配置文件
require_once(__DIR__ . '/../config/config.php');

// 初始化数据库连接
try {
    // 获取数据库配置
    $config = require(__DIR__ . '/../config/config.php');
    $db_config = $config['database'];

    $db = new PDO(
        "mysql:host=" . $db_config['host'] . ";port=" . $db_config['port'] . ";dbname=" . $db_config['database'] . ";charset=utf8mb4",
        $db_config['username'],
        $db_config['password'],
        array(
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        )
    );
} catch (PDOException $e) {
    die('数据库连接失败: ' . $e->getMessage());
}

// 获取当前页面
$page = isset($_GET['page']) ? $_GET['page'] : 'dashboard';

// 验证用户是否登录（除了登录页面）
if ($page != 'login' && !isset($_SESSION['admin_logged_in'])) {
    header('Location: index.php?page=login');
    exit;
}

// 定义侧边栏菜单
$menu_items = [
    'dashboard' => [
        'title' => '控制台',
        'icon' => 'bi bi-speedometer2'
    ],
    'software' => [
        'title' => '软件管理',
        'icon' => 'bi bi-box'
    ],
    'routes' => [
        'title' => '线路管理',
        'icon' => 'bi bi-diagram-3'
    ],
    'login_logs' => [
        'title' => '登录日志',
        'icon' => 'bi bi-clock-history'
    ],
    'profile' => [
        'title' => '个人设置',
        'icon' => 'bi bi-person'
    ],
    'version' => [
        'title' => '版本信息',
        'icon' => 'bi bi-info-circle'
    ]
];
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理后台</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        :root {
            --sidebar-width: 280px;
            --sidebar-collapsed-width: 70px;
            --primary-color: #4154f1;
            --secondary-color: #2eca6a;
            --info-color: #4154f1;
            --warning-color: #ff771d;
            --sidebar-bg: #fff;
            --sidebar-hover: #f6f9ff;
            --text-color: #012970;
            --text-light: #899bbd;
            --transition-speed: 0.3s;
            --card-shadow: 0 0 20px rgba(1, 41, 112, 0.1);
        }

        body {
            min-height: 100vh;
            background-color: #f6f9ff;
            overflow-x: hidden;
            color: var(--text-color);
            display: flex;
            flex-direction: column;
        }

        /* 侧边栏基础样式 */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: var(--sidebar-width);
            background: var(--sidebar-bg);
            transition: all var(--transition-speed) ease;
            z-index: 1000;
            box-shadow: var(--card-shadow);
            padding-top: 0;
            display: flex;
            flex-direction: column;
        }

        .sidebar-collapsed {
            width: var(--sidebar-collapsed-width);
        }

        /* 侧边栏头部样式 */
        .sidebar-header {
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 1.5rem;
            border-bottom: 1px solid #e0e0e0;
            position: relative;
        }

        .sidebar-header h5 {
            margin: 0;
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--text-color);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            width: 100%;
            text-align: center;
        }

        /* 侧边栏菜单样式 */
        .sidebar-menu {
            list-style: none;
            padding: 1rem 0;
            margin: 0;
            flex: 1;
            overflow-y: auto;
        }

        .sidebar-menu li {
            margin: 0.25rem 1rem;
        }

        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 0.875rem 1.25rem;
            color: var(--text-color);
            text-decoration: none;
            border-radius: 0.5rem;
            transition: all var(--transition-speed) ease;
            white-space: nowrap;
        }

        .sidebar-menu a:hover {
            background: var(--sidebar-hover);
            color: var(--primary-color);
        }

        .sidebar-menu a.active {
            background: var(--sidebar-hover);
            color: var(--primary-color);
        }

        .sidebar-menu i {
            width: 1.5rem;
            margin-right: 1rem;
            font-size: 1.25rem;
            text-align: center;
            color: var(--primary-color);
        }

        .sidebar-menu span {
            font-size: 0.95rem;
            font-weight: 500;
        }

        /* 主内容区域样式 */
        .main-content {
            margin-left: var(--sidebar-width);
            margin-top: 60px;
            padding: 2rem;
            flex: 1;
            min-height: calc(100vh - 60px);
            transition: margin-left var(--transition-speed) ease;
            background-color: #f5f8fa;
        }

        .main-content-expanded {
            margin-left: var(--sidebar-collapsed-width);
        }

        /* 折叠按钮样式 */
        .sidebar-toggle {
            width: 32px;
            height: 32px;
            background: var(--primary-color);
            border: none;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all var(--transition-speed) ease;
            color: white;
        }

        .sidebar-toggle:hover {
            background: var(--primary-hover);
            transform: scale(1.1);
        }

        .sidebar-toggle i {
            font-size: 1rem;
            transition: transform var(--transition-speed) ease;
        }

        .sidebar-collapsed + .main-content .sidebar-toggle {
            left: calc(var(--sidebar-collapsed-width) - 1.5rem);
        }

        .sidebar-collapsed + .main-content .sidebar-toggle i {
            transform: rotate(180deg);
        }

        /* 退出登录按钮样式 */
        .logout-link {
            color: #dc3545 !important;
            margin: 1rem;
            border-radius: 8px;
            border: 1px solid rgba(220, 53, 69, 0.2);
        }

        .logout-link:hover {
            background: rgba(220, 53, 69, 0.1) !important;
        }

        /* 响应式调整 */
        @media (max-width: 768px) {
            :root {
                --sidebar-width: var(--sidebar-collapsed-width);
            }

            .sidebar {
                width: var(--sidebar-collapsed-width);
            }

            .main-content {
                margin-left: var(--sidebar-collapsed-width);
                padding: 1rem;
            }

            .sidebar-menu span {
                display: none;
            }

            .sidebar-header h5 {
                display: none;
            }

            .sidebar-toggle {
                display: flex;
            }
        }

        /* 美化滚动条 */
        .sidebar::-webkit-scrollbar {
            width: 5px;
        }

        .sidebar::-webkit-scrollbar-track {
            background: var(--sidebar-bg);
        }

        .sidebar::-webkit-scrollbar-thumb {
            background: var(--text-light);
            border-radius: 3px;
        }

        /* 卡片样式统一 */
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: var(--card-shadow);
            transition: all 0.3s ease;
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .card-header {
            background: transparent;
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
            padding: 1.5rem;
        }

        /* 表格样式统一 */
        .table {
            margin-bottom: 0;
        }

        .table th {
            font-weight: 600;
            background: #f8f9fa;
        }

        /* 修改顶栏样式 */
        .top-navbar {
            position: fixed;
            top: 0;
            right: 0;
            left: var(--sidebar-width);
            height: 60px;
            background: var(--sidebar-bg);
            box-shadow: var(--card-shadow);
            z-index: 998;
            padding: 0 1.5rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            transition: left var(--transition-speed) ease;
        }

        .top-navbar-brand {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--text-color);
        }

        .top-navbar-right {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .user-dropdown {
            display: flex;
            align-items: center;
            gap: 0.8rem;
            padding: 0.75rem 1rem;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            transition: all 0.2s ease;
            min-width: 200px;
            height: 42px;
        }

        .user-dropdown:hover {
            background: var(--sidebar-hover);
            transform: translateY(-1px);
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        .user-dropdown:active {
            transform: translateY(0);
        }

        .user-avatar {
            width: 28px;
            height: 28px;
            border-radius: 50%;
            background: var(--primary-color);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 0.9rem;
            flex-shrink: 0;
        }

        .user-info {
            flex: 1;
            min-width: 0;
            height: 100%;
            line-height: 1.2;
        }

        .user-info .fw-bold {
            font-size: 0.9rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            margin-bottom: 2px;
        }

        .user-info .small {
            font-size: 0.75rem;
        }

        .user-info .text-danger {
            font-size: 0.75rem;
        }

        @media (max-width: 768px) {
            .user-dropdown {
                min-width: auto;
                padding: 0.5rem;
                height: 38px;
            }
            
            .user-avatar {
                width: 24px;
                height: 24px;
                font-size: 0.8rem;
            }
            
            .user-info {
                display: none;
            }
        }

        /* 修改主内容区域样式以适应顶部导航栏 */
        .main-content {
            margin-top: 60px;
            padding-top: 1.5rem;
        }

        /* 修改侧边栏样式 */
        .sidebar {
            padding-top: 0;
            display: flex;
            flex-direction: column;
        }

        .sidebar-header {
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(0, 0, 0, 0.1);
        }

        .sidebar-menu {
            flex: 1;
            overflow-y: auto;
        }

        .sidebar-footer {
            padding: 1rem;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        /* 响应式调整 */
        @media (max-width: 768px) {
            .top-navbar {
                left: var(--sidebar-collapsed-width);
                padding: 0 1rem;
            }
            
            .user-info {
                display: none;
            }
        }

        /* 修改折叠状态下的头部样式 */
        .sidebar-collapsed .sidebar-header h5 {
            opacity: 0;
            transition: opacity var(--transition-speed) ease;
        }

        /* 响应式调整 */
        @media (max-width: 768px) {
            .sidebar-header h5 {
                opacity: 0;
            }
        }

        /* 添加弹出层样式 */
        .modal-backdrop {
            z-index: 1040;
        }
        
        .modal {
            z-index: 1050;
        }

        /* 添加下拉菜单样式 */
        .dropdown-menu {
            z-index: 1060;
        }

        /* 当侧边栏折叠时的顶栏样式 */
        .sidebar-collapsed ~ .top-navbar {
            left: var(--sidebar-collapsed-width);
        }

        /* 修改主内容区域样式 */
        .main-content {
            margin-left: var(--sidebar-width);
            margin-top: 60px;
            padding: 2rem;
            flex: 1;
            min-height: calc(100vh - 60px);
            transition: margin-left var(--transition-speed) ease;
            background-color: #f5f8fa;
        }

        .main-content-expanded {
            margin-left: var(--sidebar-collapsed-width);
        }

        /* 响应式调整 */
        @media (max-width: 768px) {
            .top-navbar {
                left: var(--sidebar-collapsed-width);
                padding: 0 1rem;
            }

            .main-content {
                margin-left: var(--sidebar-collapsed-width);
                padding: 1rem;
            }
        }
    </style>
</head>
<body>
    <!-- 侧边栏 -->
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <h5>管理后台</h5>
        </div>
        <ul class="sidebar-menu">
            <?php foreach ($menu_items as $menu_page => $item): ?>
            <li>
                <a href="?page=<?php echo $menu_page; ?>" 
                   class="<?php echo $page === $menu_page ? 'active' : ''; ?>">
                    <i class="<?php echo $item['icon']; ?>"></i>
                    <span><?php echo $item['title']; ?></span>
                </a>
            </li>
            <?php endforeach; ?>
        </ul>
    </div>

    <!-- 顶栏 - 移动到这里 -->
    <div class="top-navbar" id="top-navbar">
        <div class="d-flex align-items-center">
            <button class="sidebar-toggle" id="sidebar-toggle">
                <i class="bi bi-chevron-left"></i>
            </button>
            <span class="top-navbar-brand ms-3">管理后台</span>
        </div>
        <div class="top-navbar-right">
            <!-- 添加清除缓存按钮 -->
            <button class="btn btn-outline-primary btn-sm me-2" id="clearCacheBtn">
                <i class="bi bi-arrow-clockwise"></i>
                <span class="d-none d-md-inline ms-1">清除缓存</span>
            </button>
            <div class="user-dropdown" onclick="window.location.href='?page=profile'" style="cursor: pointer;">
                <div class="user-avatar">
                    <?php echo isset($_SESSION['admin_username']) ? strtoupper(substr($_SESSION['admin_username'], 0, 1)) : 'A'; ?>
                </div>
                <div class="user-info d-flex flex-column justify-content-center">
                    <div class="fw-bold"><?php echo isset($_SESSION['admin_username']) ? $_SESSION['admin_username'] : 'Admin'; ?></div>
                    <div class="small text-muted d-flex align-items-center justify-content-between">
                        <span>管理员</span>
                        <a href="logout.php" class="text-danger ms-2" style="text-decoration: none;" onclick="event.stopPropagation();">
                            <i class="bi bi-box-arrow-right"></i> 退出
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 主内容区域 -->
    <div class="main-content" id="main-content">
        <!-- 页面内容 -->
        <div class="container-fluid">
            <?php
            $page_file = "pages/{$page}.php";
            if (file_exists($page_file)) {
                include $page_file;
            } else {
                echo '<div class="alert alert-danger">页面不存在</div>';
            }
            ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.getElementById('sidebar');
            const mainContent = document.getElementById('main-content');
            const topNavbar = document.getElementById('top-navbar');
            const toggleBtn = document.getElementById('sidebar-toggle');
            
            // 从 localStorage 获取侧边栏状态
            const isSidebarCollapsed = localStorage.getItem('sidebarCollapsed') === 'true';
            if (isSidebarCollapsed) {
                sidebar.classList.add('sidebar-collapsed');
                mainContent.classList.add('main-content-expanded');
                toggleBtn.querySelector('i').style.transform = 'rotate(180deg)';
            }
            
            toggleBtn.addEventListener('click', function() {
                sidebar.classList.toggle('sidebar-collapsed');
                mainContent.classList.toggle('main-content-expanded');
                
                // 更新按钮图标旋转
                const isCollapsed = sidebar.classList.contains('sidebar-collapsed');
                toggleBtn.querySelector('i').style.transform = isCollapsed ? 'rotate(180deg)' : '';
                
                // 保存侧边栏状态到 localStorage
                localStorage.setItem('sidebarCollapsed', isCollapsed);
            });
            
            // 添加移动端手势支持
            let touchStartX = 0;
            document.addEventListener('touchstart', function(e) {
                touchStartX = e.touches[0].clientX;
            });
            
            document.addEventListener('touchend', function(e) {
                const touchEndX = e.changedTouches[0].clientX;
                const diff = touchEndX - touchStartX;
                
                if (Math.abs(diff) > 100) { // 最小滑动距离
                    const isCollapsed = sidebar.classList.contains('sidebar-collapsed');
                    if (diff > 0 && isCollapsed) {
                        // 向右滑动，展开侧边栏
                        sidebar.classList.remove('sidebar-collapsed');
                        mainContent.classList.remove('main-content-expanded');
                        toggleBtn.querySelector('i').style.transform = '';
                    } else if (diff < 0 && !isCollapsed) {
                        // 向左滑动，收起侧边栏
                        sidebar.classList.add('sidebar-collapsed');
                        mainContent.classList.add('main-content-expanded');
                        toggleBtn.querySelector('i').style.transform = 'rotate(180deg)';
                    }
                    localStorage.setItem('sidebarCollapsed', sidebar.classList.contains('sidebar-collapsed'));
                }
            });

            // 添加清除缓存功能
            const clearCacheBtn = document.getElementById('clearCacheBtn');
            clearCacheBtn.addEventListener('click', function() {
                // 禁用按钮并显示加载状态
                clearCacheBtn.disabled = true;
                const originalContent = clearCacheBtn.innerHTML;
                clearCacheBtn.innerHTML = '<i class="bi bi-arrow-clockwise"></i> <span class="d-none d-md-inline ms-1">清除中...</span>';
                
                // 发送清除缓存请求
                fetch('clear_cache.php')
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            // 显示成功消息
                            alert('缓存已成功清除！');
                            // 刷新页面
                            window.location.reload();
                        } else {
                            throw new Error(data.message || '清除缓存失败');
                        }
                    })
                    .catch(error => {
                        alert('清除缓存失败：' + error.message);
                    })
                    .finally(() => {
                        // 恢复按钮状态
                        clearCacheBtn.disabled = false;
                        clearCacheBtn.innerHTML = originalContent;
                    });
            });
        });
    </script>
</body>
</html>


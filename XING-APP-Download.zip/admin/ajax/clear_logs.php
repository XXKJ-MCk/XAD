<?php
require_once(__DIR__ . '/../../config/database.php');
require_once(__DIR__ . '/../../config/common.php');

// 检查是否是管理员登录状态
check_admin_login();

// 检查是否是POST请求
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die(json_encode(['success' => false, 'message' => '无效的请求方法']));
}

// 获取POST数据
$data = json_decode(file_get_contents('php://input'), true);

if ($data['action'] === 'clear_login_logs') {
    try {
        // 清空登录日志表
        $sql = "TRUNCATE TABLE login_logs";
        if ($db->query($sql)) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => '清空日志失败']);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => '无效的操作']);
} 
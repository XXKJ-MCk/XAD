<?php
define('IN_ADMIN', true);
require_once(__DIR__ . '/../includes/config.php');

if (!isset($_SESSION['admin_logged_in'])) {
    http_response_code(403);
    exit('未登录');
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if (!$id) {
    http_response_code(400);
    exit('参数错误');
}

try {
    $stmt = $db->prepare("SELECT * FROM software WHERE id = ?");
    $stmt->execute([$id]);
    $software = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$software) {
        http_response_code(404);
        exit('软件不存在');
    }
    
    header('Content-Type: application/json');
    echo json_encode($software);
} catch (Exception $e) {
    http_response_code(500);
    exit('服务器错误');
} 
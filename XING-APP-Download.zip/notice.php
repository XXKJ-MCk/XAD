<?php
require_once(__DIR__ . '/config/database.php');
require_once(__DIR__ . '/config/common.php');

// 添加缓存相关函数
function getCache($key, $ttl = 300) {
    $cache_file = __DIR__ . '/cache/' . md5($key);
    if (file_exists($cache_file) && (time() - filemtime($cache_file)) < $ttl) {
        return unserialize(file_get_contents($cache_file));
    }
    return false;
}

// 添加缓存文件名哈希和路径检查
function getCacheFilename($key) {
    $hash = hash('sha256', $key);
    return __DIR__ . '/cache/' . substr($hash, 0, 32);
}

// 缓存写入时添加权限控制
function setCache($key, $data, $ttl = 300) {
    $cache_file = getCacheFilename($key);
    $dir = dirname($cache_file);
    
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    
    $tmp_file = $cache_file . '.tmp.' . uniqid();
    file_put_contents($tmp_file, serialize($data));
    chmod($tmp_file, 0640);
    rename($tmp_file, $cache_file);
}

// 添加访问控制
session_start();
if (!isset($_SESSION['last_access'])) {
    $_SESSION['last_access'] = time();
} elseif (time() - $_SESSION['last_access'] > 3600) {
    session_regenerate_id(true);
}

// 使用预处理语句防SQL注入
$stmt = $db->prepare("SELECT code, name FROM software WHERE status = ? ORDER BY created_at DESC");
$stmt->execute([1]);

// 添加缓存机制
$cache_key = 'software_list';
$software_list = getCache($cache_key);
if ($software_list === false) {
    $software_list = $stmt->fetchAll(PDO::FETCH_ASSOC);
    setCache($cache_key, $software_list, 300);
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>访问说明</title>
    <style>
        :root {
            --primary-color: #4f46e5;
            --primary-hover: #4338ca;
            --text-color: #1f2937;
            --bg-color: #f3f4f6;
            --border-color: #e5e7eb;
            --card-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Noto Sans SC", sans-serif;
            line-height: 1.6;
            background: var(--bg-color);
            color: var(--text-color);
            padding: 2rem;
            min-height: 100vh;
        }

        .container {
            max-width: 900px;
            margin: 0 auto;
            background: #fff;
            padding: 2.5rem;
            border-radius: 1rem;
            box-shadow: var(--card-shadow);
        }

        h1 {
            text-align: center;
            margin-bottom: 2rem;
            color: var(--text-color);
            font-size: 2rem;
            font-weight: 600;
        }

        h2 {
            color: var(--text-color);
            font-size: 1.5rem;
            margin-bottom: 1.5rem;
            font-weight: 500;
        }

        .notice-box {
            background: #f8fafc;
            padding: 1.5rem;
            border-radius: 0.75rem;
            margin-bottom: 2rem;
            border: 1px solid var(--border-color);
        }

        .notice-box p {
            margin-bottom: 1rem;
            font-size: 1.1rem;
        }

        .example {
            background: #f1f5f9;
            padding: 1rem 1.5rem;
            border-radius: 0.5rem;
            font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
            margin: 1rem 0;
            font-size: 0.95rem;
            border: 1px solid #e2e8f0;
        }

        .software-list {
            display: grid;
            gap: 1rem;
        }

        .software-item {
            background: #ffffff;
            padding: 1.5rem;
            border-radius: 0.75rem;
            border: 1px solid var(--border-color);
            transition: all 0.3s ease;
        }

        .software-item:hover {
            transform: translateY(-2px);
            box-shadow: var(--card-shadow);
        }

        .software-item p {
            margin-bottom: 0.5rem;
            font-size: 1.1rem;
        }

        .software-name {
            font-weight: 500;
            color: var(--text-color);
            margin-bottom: 0.5rem;
        }

        .software-code {
            color: #6b7280;
            font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
            background: #f1f5f9;
            padding: 0.25rem 0.5rem;
            border-radius: 0.25rem;
            font-size: 0.9rem;
        }

        .software-item a {
            display: inline-block;
            margin-top: 1rem;
            padding: 0.5rem 1rem;
            background: var(--primary-color);
            color: white;
            text-decoration: none;
            border-radius: 0.5rem;
            transition: background-color 0.2s ease;
        }

        .software-item a:hover {
            background: var(--primary-hover);
        }

        @media (max-width: 640px) {
            body {
                padding: 1rem;
            }
            
            .container {
                padding: 1.5rem;
            }
            
            h1 {
                font-size: 1.75rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>访问说明</h1>
        
        <div class="notice-box">
            <p>请在网址后面添加参数 <strong>?code=软件代码</strong> 来访问指定软件。</p>
            <div class="example">
                例如：http://您的域名/index.php?code=软件代码
            </div>
        </div>

        <div class="software-list">
            <h2>可用的软件列表</h2>
            <?php if (!empty($software_list)): ?>
                <?php foreach ($software_list as $software): ?>
                    <div class="software-item">
                        <div class="software-name">
                            <?php echo htmlspecialchars($software['name']); ?>
                        </div>
                        <div>
                            访问代码：<span class="software-code"><?php echo htmlspecialchars($software['code']); ?></span>
                        </div>
                        <a href="index.php?code=<?php echo urlencode($software['code']); ?>">立即访问</a>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>暂无可用软件</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html> 
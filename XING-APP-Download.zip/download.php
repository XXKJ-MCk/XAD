<?php
require_once(__DIR__ . '/config/database.php');
require_once(__DIR__ . '/config/common.php');

// 获取参数
$software_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$route_id = isset($_GET['route']) ? intval($_GET['route']) : 0;
$platform = isset($_GET['platform']) ? trim($_GET['platform']) : '';

// 验证软件ID
if (!$software_id) {
    die('参数错误：缺少软件ID');
}

// 获取软件信息
$stmt = $db->prepare("SELECT * FROM software WHERE id = :id AND status = 1");
$stmt->execute(['id' => $software_id]);
$software = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$software) {
    die('软件不存在或已下架');
}

// 获取下载URL
$download_url = '';

if ($route_id) {
    // 如果指定了线路，获取线路信息
    $stmt = $db->prepare("SELECT * FROM routes WHERE id = :id AND software_id = :software_id AND status = 1");
    $stmt->execute([
        'id' => $route_id,
        'software_id' => $software_id
    ]);
    $route = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($route) {
        $download_url = $route['url'];
    }
}

// 如果没有获取到线路URL，使用软件默认下载地址
if (empty($download_url)) {
    // 根据平台选择对应的下载地址
    switch ($platform) {
        case 'windows':
            $download_url = $software['file_path_windows'] ?? $software['file_path'];
            break;
        case 'mac':
            $download_url = $software['file_path_mac'] ?? $software['file_path'];
            break;
        default:
            $download_url = $software['file_path'];
    }
}

if (empty($download_url)) {
    die('下载地址未配置');
}

// 添加防盗链验证
$referer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '';
$host = $_SERVER['HTTP_HOST'];
if (!empty($referer) && strpos($referer, $host) === false) {
    die('非法访问');
}

// 添加文件存在性检查
if (!empty($download_url) && !filter_var($download_url, FILTER_VALIDATE_URL)) {
    if (!file_exists($download_url)) {
        die('文件不存在');
    }
}

// 添加文件类型白名单验证
function isAllowedFileType($filename) {
    $allowed = ['exe', 'dmg', 'zip', 'rar', 'pdf']; // 根据实际需求配置
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    return in_array($ext, $allowed);
}

// 在下载前验证
if (!isAllowedFileType($download_url)) {
    die('不支持的文件类型');
}

// 添加下载速率限制
function downloadFile($file, $speed = 1024) {
    if (file_exists($file)) {
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="'.basename($file).'"');
        header('Content-Length: ' . filesize($file));
        
        $handle = fopen($file, 'rb');
        while (!feof($handle)) {
            print fread($handle, round($speed * 1024));
            flush();
            sleep(1);
        }
        fclose($handle);
    }
}

// 更新下载次数
$stmt = $db->prepare("UPDATE software SET download_count = download_count + 1 WHERE id = :id");
$stmt->execute(['id' => $software_id]);

// 记录下载日志（可选）
$stmt = $db->prepare("INSERT INTO download_logs (software_id, route_id, ip, user_agent, platform, download_time) 
                     VALUES (:software_id, :route_id, :ip, :user_agent, :platform, NOW())");
$stmt->execute([
    'software_id' => $software_id,
    'route_id' => $route_id,
    'ip' => $_SERVER['REMOTE_ADDR'],
    'user_agent' => $_SERVER['HTTP_USER_AGENT'],
    'platform' => $platform
]);

// 重定向到实际的下载地址
header("Location: " . $download_url);
exit;
<?php
/**
 * 系统版本配置文件
 */

// 系统版本号
define('SYSTEM_VERSION', '1.0.0');

// 系统构建号
define('SYSTEM_BUILD', date('Ymd'));

// 系统发布日期
define('SYSTEM_RELEASE_DATE', '2024-03-20');

// 系统名称
define('SYSTEM_NAME', 'Admin System');

// 系统简称
define('SYSTEM_SHORT_NAME', 'Admin');
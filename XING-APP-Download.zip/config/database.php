<?php
function get_db_connection() {
    static $db = null;
    
    if ($db instanceof PDO) {
        return $db;
    }
    
    try {
        // 获取数据库配置
        $config = require(__DIR__ . '/config.php');
        $db_config = $config['database'];
        
        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
        ];
        
        $dsn = "mysql:host={$db_config['host']};port={$db_config['port']};dbname={$db_config['database']};charset=utf8mb4";
        $db = new PDO($dsn, $db_config['username'], $db_config['password'], $options);
        
        // 测试连接
        $db->query("SELECT 1");
        
        return $db;
    } catch (PDOException $e) {
        error_log("数据库连接失败: " . $e->getMessage());
        throw new Exception("数据库连接失败，请检查配置或联系管理员");
    }
}

// 创建全局数据库连接
try {
    $db = get_db_connection();
} catch (Exception $e) {
    die($e->getMessage());
}


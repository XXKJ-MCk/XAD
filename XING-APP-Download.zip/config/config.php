<?php
return array (
  'database' => 
  array (
    'host' => 'localhost',
    'port' => '3306',
    'database' => 'xzy',
    'username' => 'root',
    'password' => '123456',
  ),
  'system' => 
  array (
    'version' => '1.0.0',
    'build' => '100',
    'release_date' => '2024-11-10',
    'name' => 'XAD管理系统',
    'short_name' => 'Admin',
  ),
);

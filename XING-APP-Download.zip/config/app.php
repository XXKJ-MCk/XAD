<?php
return [
    // 基础配置
    'template' => [
        'path' => '/path/to/admin-template',
        'theme' => 'default',
    ],
    
    // 应用特定配置
    'app' => [
        'name' => '应用名称',
        'version' => '1.0.0',
        'modules' => [
            // 启用的功能模块
            'users' => true,
            'routes' => true,
            'stats' => false,
        ]
    ],
    
    // 自定义页面和功能
    'custom' => [
        'pages' => [
            // 自定义页面配置
        ],
        'menu' => [
            // 自定义菜单项
        ]
    ]
]; 
<?php
// 错误报告设置
error_reporting(E_ALL);
ini_set('display_errors', 1);

// 设置时区
date_default_timezone_set('Asia/Shanghai');

// 通用函数
function safe_html($str) {
    return htmlspecialchars($str, ENT_QUOTES | ENT_HTML5, 'UTF-8');
}

// 检查是否已安装
function check_install() {
    if (!file_exists(__DIR__ . '/install.lock')) {
        header('Location: /install/index.php');
        exit;
    }
}

// 添加 CSRF 防护函数
function generate_csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        try {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        } catch (Exception $e) {
            error_log("Failed to generate CSRF token: " . $e->getMessage());
            return false;
        }
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf_token($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// 增强登录状态检查
function check_admin_login() {
    session_start();
    
    // 检查会话是否已启动
    if (session_status() !== PHP_SESSION_ACTIVE) {
        return false;
    }
    
    if (!isset($_SESSION['admin_logged_in'])) {
        if (!check_remember_cookie()) {
            header('Location: login.php');
            exit;
        }
    }
    
    // 检查会话是否过期
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > 1800)) {
        session_unset();
        session_destroy();
        header('Location: login.php');
        exit;
    }
    
    // 更新最后活动时间
    $_SESSION['last_activity'] = time();
    
    // 验证IP地址是否改变
    if (isset($_SESSION['admin_ip']) && $_SESSION['admin_ip'] !== $_SERVER['REMOTE_ADDR']) {
        session_unset();
        session_destroy();
        header('Location: login.php');
        exit;
    }
    
    return true;
}

// 添加获取客户端IP的函数
function get_client_ip() {
    $ip_headers = [
        'HTTP_CLIENT_IP',
        'HTTP_X_FORWARDED_FOR',
        'HTTP_X_FORWARDED',
        'HTTP_X_CLUSTER_CLIENT_IP',
        'HTTP_FORWARDED_FOR',
        'HTTP_FORWARDED',
        'REMOTE_ADDR'
    ];
    
    foreach ($ip_headers as $header) {
        if (!empty($_SERVER[$header])) {
            $ip = trim($_SERVER[$header]);
            if (filter_var($ip, FILTER_VALIDATE_IP)) {
                return $ip;
            }
        }
    }
    
    return '0.0.0.0';
}

// 添加安全过滤函数
function safe_input($str) {
    return trim(strip_tags($str));
}

// 添加日期格式化函数
function format_datetime($datetime) {
    return date('Y-m-d H:i:s', strtotime($datetime));
}

function check_remember_cookie() {
    global $db;
    
    if (!isset($_SESSION['admin_logged_in']) && isset($_COOKIE['remember_token']) && isset($_COOKIE['admin_id'])) {
        $stmt = $db->prepare("SELECT * FROM admin_users WHERE id = ? AND remember_token = ? AND token_expires > NOW()");
        $stmt->execute([$_COOKIE['admin_id'], $_COOKIE['remember_token']]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user) {
            // 自动登录成功
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_username'] = $user['username'];
            $_SESSION['admin_id'] = $user['id'];
            $_SESSION['admin_ip'] = $_SERVER['REMOTE_ADDR'];
            $_SESSION['last_activity'] = time();
            
            // 更新最后登录时间
            $stmt = $db->prepare("UPDATE admin_users SET last_login = NOW() WHERE id = ?");
            $stmt->execute([$user['id']]);
            
            return true;
        }
    }
    return false;
}

// 添加自定义错误处理
function customErrorHandler($errno, $errstr, $errfile, $errline) {
    error_log("Error [$errno] $errstr on line $errline in file $errfile");
    
    if (!(error_reporting() & $errno)) {
        return false;
    }
    
    // 生产环境不显示详细错误
    if (ENVIRONMENT === 'production') {
        return true;
    }
    
    $error_output = sprintf(
        "Error: [%d] %s\nFile: %s\nLine: %d",
        $errno,
        $errstr,
        $errfile,
        $errline
    );
    
    error_log($error_output);
    return true;
}

set_error_handler('customErrorHandler');

// 添加日志大小限制和轮转
function writeLog($message, $type = 'info') {
    $log_file = __DIR__ . '/../logs/' . date('Y-m-d') . '.log';
    $max_size = 10 * 1024 * 1024; // 10MB
    
    if (file_exists($log_file) && filesize($log_file) > $max_size) {
        rename($log_file, $log_file . '.' . time() . '.bak');
    }
    
    $log_message = sprintf(
        "[%s] [%s] %s\n",
        date('Y-m-d H:i:s'),
        strtoupper($type),
        $message
    );
    
    file_put_contents($log_file, $log_message, FILE_APPEND | LOCK_EX);
}